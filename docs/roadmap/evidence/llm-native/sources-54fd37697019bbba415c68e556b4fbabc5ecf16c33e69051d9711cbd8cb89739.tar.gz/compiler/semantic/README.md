# Semantic compiler service

This package implements immutable scoped snapshots and entity indexes. See the
[roadmap](../../docs/roadmap/ROADMAP_LLM_NATIVE_COMPILER.md) for acceptance status.
It does not yet expose a live MCP server or source transactions.

The service, admission checks, identities, storage, and overlay handling are
Terlan code. The narrow bootstrap command `terlc emit-core` serializes results
from the existing authoritative compiler. It does not introduce another type
checker or a Rust MCP implementation.

## Run

Build the bootstrap exporter and its runtime once:

```sh
cargo build --locked -p terlan --bin terlc --bin terlan-vm
target/release/terlc check compiler/semantic/src
target/release/terlc run compiler/semantic/scripts/Snapshot.terls -- \
  "$PWD/target/debug/terlc" /path/to/sample.terl src/sample.terl /tmp/semantic-store
target/release/terlc run compiler/semantic/scripts/Entities.terls -- \
  /tmp/semantic-store s:THE_RETURNED_64_HEX_DIGEST
target/release/terlc run compiler/semantic/scripts/Entities.terls -- \
  /tmp/semantic-store s:THE_RETURNED_64_HEX_DIGEST declarations
target/release/terlc run compiler/semantic/scripts/SourceSet.terls -- \
  "$PWD/target/debug/terlc" tests/fixtures/llm_native/semantic/sources.json /tmp/semantic-source-set
target/release/terlc run compiler/semantic/scripts/Entities.terls -- \
  /tmp/semantic-source-set s:THE_RETURNED_64_HEX_DIGEST catalog
```

The compiler executable is trusted host configuration, not an agent-selected
program. Its export runs with a 30-second timeout and an 8-MiB output bound.
Source-set exports use a 420-second timeout and request at most 16 MiB of output.
Both paths consult the runtime's process ceilings and preserve typed failures.
No candidate application is executed. A failed check retains actual compiler
diagnostics and exports no checked Core. Stdout contains exactly one JSON
artifact, including for invalid programs; rendered diagnostics use stderr.

## Snapshot contract

`Snapshot.capture_file` freezes source before compilation. The manifest binds
source bytes, compiler binary, syntax contract, target, dependency interface
digests, flags, and static execution policy. `capture_overlay` additionally
binds a positive editor version and requires the expected disk digest before
and after compilation. It never writes editor contents into the working tree.
Disk captures use document version zero.

The initial compiler ancestry digest explicitly anchors the trusted bootstrap
binary: `sha256_domain_framed("terlan.semantic.bootstrap-root.v1", [binary_sha])`.
It is not a claim that compiler build ancestry has been independently verified.
Dependency interfaces are the actual interfaces supplied by the bootstrap
pipeline, including its required standard interfaces. Interface-only exports
include those dependencies too.

The snapshot ID hashes canonical manifest JSON without `snapshot_id` and the
normalized compiler artifact digest, using the domain
`terlan.semantic.snapshot.v1`. Physical staging paths are normalized only in
known origin fields; source literals are preserved. Store readers require the
publication marker and recheck source, document, export, and identity hashes.
Interrupted publication and artifact corruption cannot serve partial facts.
This store does not claim a durable multi-file source transaction; LNC-007 owns
that separate contract.

`SourceSet.capture` freezes an explicit list of source and overlay contents,
canonically sorts source-root-relative paths, and checks them against the same
source-interface graph as the authoritative project compiler. Each unit retains
its own checked Core, public interface, source declarations, and diagnostics.
Checked `.terli` files expose declarations without pretending to contain an
implementation. Input is limited to 1,024 files and 8 MiB of source; duplicate
paths, traversal, excluded cache paths, and negative versions fail before
compilation. The source-root exporter applies the compiler's existing module
layout validation. Supplied bytes are immutable inputs, not a claim about the
current contents of a separately edited workspace.

Source-set storage uses a versioned publication marker and generated physical
filenames. Every source, document version, unit export, and digest must agree
before reading the snapshot. Catalogs can retain conditional facts from checked
units when another unit fails; the snapshot remains `invalid`, never verified.

Analysis is explicitly `partial`, or `invalid` after compiler rejection. The
provided source set and loaded interfaces are bound; package configuration,
dependency implementations outside that set, expanded origin chains, and
automatic workspace context discovery are not claimed. Dependency interfaces
alone do not establish the correctness of their implementations.

## Entity identity

`Entities.bindings` projects the compiler's resolved lexical binding evidence.
It preserves full unsigned compiler identities through their JSON spelling.
Handles bind logical source path, module, lexical path, compiler binding ID,
and name. Unrelated declaration insertion preserves IDs; rename invalidates
the old handle. Resolution requires both snapshot ID and expected entity
digest, with no fallback to matching names. Digests conservatively bind the
whole normalized compiler unit, including dependency interfaces, so semantic
context changes require refreshed selections even when IDs remain stable.

`DeclarationEntities.declarations` indexes checked functions, receiver methods,
types, structs, and traits. IDs bind complete checked declaration payloads with
syntax `span` metadata removed. This conservative initial scheme preserves IDs
across unrelated declaration insertion and distinguishes same-name overloads;
any semantic payload change invalidates the declaration ID. Duplicate identities
are rejected. These handles are not public ABI fingerprints.

`PatternEntities.index` gives identities to checked syntax pattern nodes,
including constants, wildcards, nested children, and map/record field values.
IDs bind the owning declaration, structural syntax path, and pattern payload.
Semantic changes to the owner conservatively invalidate pattern IDs; unrelated
declaration insertion preserves them. Compiler spans are retained without
inventing coverage, inferred local types, or exact token positions.

`Catalog.index` combines module, declaration, lexical binding, and pattern
entities, including checked interface declarations across a frozen source set.
`Catalog.resolve` requires snapshot, ID, expected kind, and expected content
digest. It rejects absent, stale, and wrong-kind selections without falling
back to names or source positions. A lexical move invalidates the old handle.

Compiler lexical spans currently cover enclosing syntax. The lexical catalog
reports `span_precision: enclosing_syntax`; these ranges must not be used as
exact rename edits. Module origins are explicitly file anchors. Unexported
inferred local types, generated origins, other entity categories, and broader
workspace relations remain unavailable until their compiler evidence exists.

## Checks

```sh
target/release/terlc test compiler/semantic/src/semantic/CompilerBridgeTest.terl
target/release/terlc test compiler/semantic/src/semantic/SnapshotTest.terl
target/release/terlc test compiler/semantic/src/semantic/EntitiesTest.terl
target/release/terlc test compiler/semantic/src/semantic/DeclarationEntitiesTest.terl
target/release/terlc test compiler/semantic/src/semantic/CatalogTest.terl
target/release/terlc test compiler/semantic/src/semantic/SourceSetTest.terl
cargo test --locked -p terlan --lib commands::emit_core::tests -- --test-threads=1
```

The Terlan tests use `target/debug/terlc`, or the explicit
`TERLAN_SEMANTIC_TEST_COMPILER` override. Authored tests cover stale source and
forged-success rejection, immutable capture, corruption, invalid programs,
unsaved overlays, stable IDs, stale selection, rename invalidation, overloads,
declaration payload changes, pattern ownership and lexical moves, canonical
source-set order, imported declarations, and dependency freshness. The executable
`LNC-004` selector adds exact test inventories, current compiled-source hashes,
isolated per-suite caches, and an independently validated live source-set
snapshot/catalog. It does not close M1 or establish MCP interoperability.

Run these commands sequentially, or give concurrent invocations distinct
`--cache-dir` values. One parallel checkpoint run failed during project
interface preparation; its isolated replay passed. Shared-cache concurrency
is not established by this component checkpoint.
