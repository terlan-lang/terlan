use std::collections::HashMap;

use crate::terlan_hir::{ConstructorSignature, FunctionSignature, FunctionSymbol, ModuleInterface};

mod alias_subtyping;
pub(super) use alias_subtyping::is_subtype_with_aliases;

mod application;
use application::apply_type_constructor_subst;
mod builtins;
mod interface;
mod map_fields;
mod opaque_aliases;
pub(super) use opaque_aliases::reveal_opaque_aliases;
mod return_type;
pub(super) use return_type::unify_return_type;
pub(crate) mod parser;
mod special;
mod standard_aliases;
use special::portable_list_element;
mod substitution;
mod text;

use standard_aliases::option_representation_is_subtype;

pub(super) use builtins::{
    builtin_call, is_literal_atom, is_removed_implicit_builtin_call,
    widen_list_literal_element_type, widen_type_var_binding,
};
pub(super) use interface::{
    expand_interface_global_aliases, interface_qualified_type_names, interface_type_aliases,
    interface_type_names, parse_interface_constructor_schemes, parse_interface_signature,
    parse_symbol_scheme, qualify_type_names, unique_global_alias_short_names,
    InterfaceSignatureContext,
};
pub(super) use map_fields::{map_fields_is_subtype, unify_map_fields};
pub(super) use parser::{
    alias_constructor_param_names_from_variants, is_map_type, parse_type_expr, split_named_type,
};
pub(super) use special::{
    are_template_html_equivalent_types, are_unit_equivalent_types, is_unit_literal_type,
    is_unit_named_type,
};
pub(super) use substitution::{
    canonical_observation_type, existential_types_are_alpha_equivalent, expand_type_aliases, mapping_without_bound_params,
    substitute_type_vars,
};
pub(super) use text::{
    compact_spaces, split_module_name, split_top_level_csv, split_top_level_plus,
};

use crate::terlan_typeck::types::ArraySize;
use crate::terlan_typeck::{
    pretty_type, ConstructorScheme, MapFieldType, QualifiedTypeName, Type, TypeAlias, TypeVarId,
    Variance,
};

/// Normalizes a set of union variants.
///
/// Inputs:
/// - `types`: candidate union variants that may include nested unions.
///
/// Output:
/// - `Never` for an empty union, a single type for singleton unions, or a
///   deduplicated `Union`.
///
/// Transformation:
/// - Flattens nested unions, removes `Never`, short-circuits on `Term`, and
///   drops variants covered by wider supertypes.
pub(super) fn normalize_union(mut types: Vec<Type>) -> Type {
    let mut expanded = Vec::new();
    while let Some(ty) = types.pop() {
        match ty {
            Type::Union(items) => expanded.extend(items),
            other => expanded.push(other),
        }
    }

    let mut normalized: Vec<Type> = Vec::new();
    for candidate in expanded {
        if candidate == Type::Never {
            continue;
        }
        if candidate == Type::Term {
            return Type::Term;
        }
        if normalized
            .iter()
            .any(|existing| is_subtype(&candidate, existing))
        {
            continue;
        }
        normalized.retain(|existing| !is_subtype(existing, &candidate));
        normalized.push(candidate);
    }

    if normalized.is_empty() {
        Type::Never
    } else if normalized.len() == 1 {
        normalized.into_iter().next().unwrap()
    } else {
        Type::Union(normalized)
    }
}

/// Checks the current structural subtype relation.
///
/// Inputs:
/// - `lhs`: candidate subtype.
/// - `rhs`: expected supertype.
///
/// Output:
/// - `true` when `lhs` is assignable to `rhs` without conversion.
///
/// Transformation:
/// - Applies primitive widening, literal widening, Unit equivalence, array
///   compatibility, and structural map-field compatibility.
pub(super) fn is_subtype(lhs: &Type, rhs: &Type) -> bool {
    if lhs == rhs {
        return true;
    }
    if existential_types_are_alpha_equivalent(lhs, rhs) {
        return true;
    }
    if are_unit_equivalent_types(lhs, rhs) {
        return true;
    }
    if are_template_html_equivalent_types(lhs, rhs) {
        return true;
    }
    match (lhs, rhs) {
        (_, Type::Dynamic) => true,
        (_, Type::Term) => true,
        (Type::Int, Type::Number) => true,
        (Type::Float, Type::Number) => true,
        (Type::LiteralInt(_), Type::Int) => true,
        (Type::LiteralInt(_), Type::Number) => true,
        (Type::LiteralAtom(_), Type::Atom) => true,
        (
            Type::Array {
                size: lhs_size,
                elem: lhs_elem,
            },
            Type::Array {
                size: rhs_size,
                elem: rhs_elem,
            },
        ) => lhs_size == rhs_size && is_subtype(lhs_elem, rhs_elem),
        (Type::Map(lhs), Type::Map(rhs)) => map_fields_is_subtype(lhs, rhs),
        (Type::Never, _) => true,
        _ => false,
    }
}

/// Unifies two types and updates type-variable substitutions.
///
/// Inputs:
/// - `left`: first type constraint.
/// - `right`: second type constraint.
/// - `subst`: mutable substitution table for type variables.
///
/// Output:
/// - `Ok(())` when the types can be made compatible.
/// - `Err(message)` with a human-readable mismatch when unification fails.
///
/// Transformation:
/// - Applies existing substitutions, binds variables with occurs checks, and
///   recursively unifies composite type structure.
pub(super) fn unify(
    left: &Type,
    right: &Type,
    subst: &mut HashMap<TypeVarId, Type>,
) -> Result<(), String> {
    let left = apply_subst(left, subst);
    let right = apply_subst(right, subst);

    if are_unit_equivalent_types(&left, &right) {
        return Ok(());
    }
    if are_template_html_equivalent_types(&left, &right) {
        return Ok(());
    }
    if let (Some(left), Some(right)) = (portable_list_element(&left), portable_list_element(&right))
    {
        return unify(left, right, subst);
    }

    match (&left, &right) {
        (Type::Dynamic, _) | (_, Type::Dynamic) => Ok(()),
        (Type::Placeholder, Type::Placeholder) => Ok(()),
        (Type::Term, _) => Ok(()),
        (_, Type::Never) => Ok(()),
        (Type::Var(left_id), Type::Var(right_id)) if left_id == right_id => Ok(()),
        (Type::Var(id), rhs) => bind_var(*id, rhs.clone(), subst),
        (lhs, Type::Var(id)) => bind_var(*id, lhs.clone(), subst),
        (Type::Existential { .. }, Type::Existential { .. }) => {
            if existential_types_are_alpha_equivalent(&left, &right) {
                Ok(())
            } else {
                Err(format!(
                    "expected {} found {}",
                    pretty_type(&left),
                    pretty_type(&right)
                ))
            }
        }
        (Type::Union(left), Type::Union(right)) => {
            for r in right {
                let mut trial_ok = false;
                for l in left {
                    let mut trial_subst = subst.clone();
                    if unify(l, r, &mut trial_subst).is_ok() {
                        *subst = trial_subst;
                        trial_ok = true;
                        break;
                    }
                }
                if !trial_ok {
                    return Err(format!(
                        "expected {} but could not match {}",
                        pretty_type(&Type::Union(left.to_vec())),
                        pretty_type(r)
                    ));
                }
            }
            Ok(())
        }
        (Type::Union(left), rhs) => {
            for l in left {
                let mut trial_subst = subst.clone();
                if unify(l, rhs, &mut trial_subst).is_ok() {
                    *subst = trial_subst;
                    return Ok(());
                }
            }
            Err(format!(
                "expected {} found {}",
                pretty_type(&Type::Union(left.clone())),
                pretty_type(rhs)
            ))
        }
        (lhs, Type::Union(right)) => {
            for r in right {
                let mut trial_subst = subst.clone();
                if unify(lhs, r, &mut trial_subst).is_err() {
                    return Err(format!(
                        "expected {} found {}",
                        pretty_type(lhs),
                        pretty_type(&Type::Union(right.clone()))
                    ));
                }
                *subst = trial_subst;
            }
            Ok(())
        }
        (Type::Int, Type::Number) => Ok(()),
        (Type::Float, Type::Number) => Ok(()),
        (Type::LiteralInt(_), Type::Number) => Ok(()),
        (Type::Number, Type::LiteralInt(_)) => Ok(()),
        (Type::Number, Type::Int) | (Type::Number, Type::Float) => {
            Err("expected Number but found Int/Float".to_string())
        }
        (Type::LiteralAtom(left_atom), Type::LiteralAtom(right_atom))
            if left_atom == right_atom =>
        {
            Ok(())
        }
        (Type::LiteralInt(left_int), Type::LiteralInt(right_int)) if left_int == right_int => {
            Ok(())
        }
        (Type::Int, Type::Int)
        | (Type::Float, Type::Float)
        | (Type::Number, Type::Number)
        | (Type::Atom, Type::Atom)
        | (Type::Atom, Type::LiteralAtom(_))
        | (Type::LiteralAtom(_), Type::Atom)
        | (Type::Int, Type::LiteralInt(_))
        | (Type::LiteralInt(_), Type::Int)
        | (Type::Binary, Type::Binary)
        | (Type::Bool, Type::Bool) => Ok(()),
        (Type::Map(lhs_fields), Type::Map(rhs_fields)) => {
            unify_map_fields(lhs_fields, rhs_fields, subst)
        }
        (Type::Tuple(lhs), Type::Tuple(rhs)) => {
            if lhs.len() != rhs.len() {
                return Err(format!(
                    "tuple arity mismatch: expected {} elements, found {}",
                    lhs.len(),
                    rhs.len()
                ));
            }
            for (left_item, right_item) in lhs.iter().zip(rhs.iter()) {
                unify(left_item, right_item, subst)?;
            }
            Ok(())
        }
        (
            Type::Named {
                module: m1,
                name: n1,
                args: args1,
            },
            Type::Named {
                module: m2,
                name: n2,
                args: args2,
            },
        ) => {
            if m1 == m2 && n1 == n2 && args1.len() == args2.len() {
                for (a, b) in args1.iter().zip(args2.iter()) {
                    unify(a, b, subst)?;
                }
                Ok(())
            } else {
                Err(format!(
                    "expected {} found {}",
                    pretty_type(&Type::Named {
                        module: m1.clone(),
                        name: n1.clone(),
                        args: args1.clone(),
                    }),
                    pretty_type(&Type::Named {
                        module: m2.clone(),
                        name: n2.clone(),
                        args: args2.clone(),
                    })
                ))
            }
        }
        (
            Type::Apply { constructor, args },
            Type::Named {
                module,
                name,
                args: named_args,
            },
        )
        | (
            Type::Named {
                module,
                name,
                args: named_args,
            },
            Type::Apply { constructor, args },
        ) => {
            unify_type_constructor_application(*constructor, args, module, name, named_args, subst)
        }
        (
            Type::Apply {
                constructor: left_constructor,
                args: left_args,
            },
            Type::Apply {
                constructor: right_constructor,
                args: right_args,
            },
        ) => {
            if left_constructor == right_constructor && left_args.len() == right_args.len() {
                for (left_arg, right_arg) in left_args.iter().zip(right_args.iter()) {
                    unify(left_arg, right_arg, subst)?;
                }
                Ok(())
            } else {
                Err(format!(
                    "expected {} found {}",
                    pretty_type(&left),
                    pretty_type(&right)
                ))
            }
        }
        (
            Type::Function {
                params: params_a,
                ret: ret_a,
            },
            Type::Function {
                params: params_b,
                ret: ret_b,
            },
        ) => {
            if params_a.len() != params_b.len() {
                return Err(format!(
                    "function arity mismatch: expected {} args, found {}",
                    params_a.len(),
                    params_b.len()
                ));
            }
            for (a, b) in params_a.iter().zip(params_b.iter()) {
                unify(a, b, subst)?;
            }
            unify(ret_a.as_ref(), ret_b.as_ref(), subst)
        }
        (
            Type::Array {
                size: size_a,
                elem: elem_a,
            },
            Type::Array {
                size: size_b,
                elem: elem_b,
            },
        ) => {
            let resolved_size_a = size_a.substitute(subst);
            let resolved_size_b = size_b.substitute(subst);
            unify_array_sizes(resolved_size_a, resolved_size_b, subst).map_err(|()| {
                format!(
                    "expected {} found {}",
                    pretty_type(&Type::Array {
                        size: resolved_size_a,
                        elem: elem_a.clone(),
                    }),
                    pretty_type(&Type::Array {
                        size: resolved_size_b,
                        elem: elem_b.clone(),
                    })
                )
            })?;
            unify(elem_a, elem_b, subst)
        }
        _ => Err(format!(
            "expected {} found {}",
            pretty_type(&left),
            pretty_type(&right)
        )),
    }
}

#[cfg(test)]
#[path = "type_system_test.rs"]
mod list_boundary_tests;

#[cfg(test)]
#[path = "type_system/union_substitution_test.rs"]
mod union_substitution_tests;

/// Unifies an applied constructor variable with a concrete named type.
///
/// Inputs:
/// - `constructor` and `args`: higher-kinded application such as `F[Bool]`.
/// - `module`, `name`, and `named_args`: concrete application such as
///   `Deferred[Bool]`.
/// - `subst`: active inference substitutions.
///
/// Output:
/// - Successful constructor and argument bindings, or an arity mismatch.
///
/// Transformation:
/// - Binds `F` to the unapplied named constructor and unifies the applied
///   suffix. Leading named arguments remain on a partially applied constructor.
fn unify_type_constructor_application(
    constructor: TypeVarId,
    args: &[Type],
    module: &Option<String>,
    name: &str,
    named_args: &[Type],
    subst: &mut HashMap<TypeVarId, Type>,
) -> Result<(), String> {
    let Some(split) = named_args.len().checked_sub(args.len()) else {
        return Err(format!(
            "type-constructor arity mismatch: expected at least {} arguments, found {}",
            args.len(),
            named_args.len()
        ));
    };
    bind_var(
        constructor,
        Type::Named {
            module: module.clone(),
            name: name.to_string(),
            args: named_args[..split].to_vec(),
        },
        subst,
    )?;
    for (expected, actual) in args.iter().zip(&named_args[split..]) {
        unify(expected, actual, subst)?;
    }
    Ok(())
}

/// Unifies the compile-time size component of two array types.
///
/// Const-generic parameters deliberately retain their integer singleton value;
/// ordinary type-variable binding widens integer literals to `Int`, which would
/// erase the array identity needed by `Array[N, T]`.
fn unify_array_sizes(
    left: ArraySize,
    right: ArraySize,
    subst: &mut HashMap<TypeVarId, Type>,
) -> Result<(), ()> {
    match (left, right) {
        (ArraySize::Known(left), ArraySize::Known(right)) if left == right => Ok(()),
        (ArraySize::Param(left), ArraySize::Param(right)) if left == right => Ok(()),
        (ArraySize::Param(id), ArraySize::Known(value))
        | (ArraySize::Known(value), ArraySize::Param(id)) => bind_array_size(
            id,
            Type::LiteralInt(i64::try_from(value).map_err(|_| ())?),
            subst,
        ),
        (ArraySize::Param(left), ArraySize::Param(right)) => {
            bind_array_size(left, Type::Var(right), subst)
        }
        (ArraySize::Known(_), ArraySize::Known(_)) => Err(()),
    }
}

fn bind_array_size(
    id: TypeVarId,
    value: Type,
    subst: &mut HashMap<TypeVarId, Type>,
) -> Result<(), ()> {
    let Some(existing) = subst.get(&id).cloned() else {
        subst.insert(id, value);
        return Ok(());
    };
    match (existing, value) {
        (Type::LiteralInt(left), Type::LiteralInt(right)) if left == right => Ok(()),
        (Type::Var(next), value) if next != id => bind_array_size(next, value, subst),
        (existing, Type::Var(next)) if next != id => bind_array_size(next, existing, subst),
        _ => Err(()),
    }
}

/// Binds a type variable to a concrete type.
///
/// Inputs:
/// - `id`: variable id being constrained.
/// - `value`: type to bind after generic literal widening.
/// - `subst`: mutable substitution table.
///
/// Output:
/// - `Ok(())` when the binding is accepted.
/// - `Err(message)` for recursive bindings or incompatible existing bindings.
///
/// Transformation:
/// - Widens literal bindings, unifies with any existing binding, checks occurs,
///   and records the substitution.
pub(super) fn bind_var(
    id: TypeVarId,
    value: Type,
    subst: &mut HashMap<TypeVarId, Type>,
) -> Result<(), String> {
    let value = widen_type_var_binding(value);
    if let Some(existing) = subst.get(&id).cloned() {
        return unify(&existing, &value, subst);
    }
    if occurs(id, &value, subst) {
        return Err("recursive type".to_string());
    }
    subst.insert(id, value);
    Ok(())
}

/// Checks whether a type variable occurs inside a candidate binding.
///
/// Inputs:
/// - `var`: variable id being tested.
/// - `value`: candidate type value.
/// - `subst`: current substitutions to apply before traversal.
///
/// Output:
/// - `true` when binding would create a recursive type.
///
/// Transformation:
/// - Applies substitutions and recursively scans composite type children.
pub(super) fn occurs(var: TypeVarId, value: &Type, subst: &HashMap<TypeVarId, Type>) -> bool {
    match apply_subst(value, subst) {
        Type::Var(other) => other == var,
        Type::Apply { constructor, args } => {
            constructor == var || args.iter().any(|arg| occurs(var, arg, subst))
        }
        Type::Existential { params, body } => {
            !params.contains(&var) && occurs(var, body.as_ref(), subst)
        }
        Type::List(inner) => occurs(var, &inner, subst),
        Type::Tuple(items) => items.iter().any(|item| occurs(var, item, subst)),
        Type::Union(items) => items.iter().any(|item| occurs(var, item, subst)),
        Type::Named { args, .. } => args.iter().any(|arg| occurs(var, arg, subst)),
        Type::Map(fields) => fields.iter().any(|field| occurs(var, &field.value, subst)),
        Type::Function { params, ret } => {
            params.iter().any(|param| occurs(var, param, subst)) || occurs(var, &ret, subst)
        }
        _ => false,
    }
}

/// Applies type-variable substitutions to a type tree.
///
/// Inputs:
/// - `ty`: type that may contain variables.
/// - `subst`: variable substitutions produced during unification.
///
/// Output:
/// - Type tree with all reachable substitutions applied.
///
/// Transformation:
/// - Recursively follows variable bindings and rewrites composite type children.
pub(super) fn apply_subst(ty: &Type, subst: &HashMap<TypeVarId, Type>) -> Type {
    match ty {
        Type::Var(id) => match subst.get(id) {
            Some(inner) => apply_subst(inner, subst),
            None => Type::Var(*id),
        },
        Type::Apply { constructor, args } => {
            apply_type_constructor_subst(*constructor, args, subst)
        }
        Type::Existential { params, body } => {
            let scoped_subst = mapping_without_bound_params(subst, params);
            Type::Existential {
                params: params.clone(),
                body: Box::new(apply_subst(body, &scoped_subst)),
            }
        }
        Type::List(inner) => Type::List(Box::new(apply_subst(inner, subst))),
        Type::Tuple(items) => {
            Type::Tuple(items.iter().map(|item| apply_subst(item, subst)).collect())
        }
        Type::Union(items) => {
            // A fresh variable can resolve to a whole union. Keep its members
            // at this level so union matching checks alternatives individually.
            // Preserve order: it also determines stable representation layouts.
            let mut flattened = Vec::with_capacity(items.len());
            for item in items {
                match apply_subst(item, subst) {
                    Type::Union(members) => flattened.extend(members),
                    other => flattened.push(other),
                }
            }
            Type::Union(flattened)
        }
        Type::Map(fields) => Type::Map(
            fields
                .iter()
                .map(|field| MapFieldType {
                    key: field.key.clone(),
                    value: apply_subst(&field.value, subst),
                    required: field.required,
                })
                .collect(),
        ),
        Type::Named { module, name, args } => Type::Named {
            module: module.clone(),
            name: name.clone(),
            args: args.iter().map(|arg| apply_subst(arg, subst)).collect(),
        },
        Type::Function { params, ret } => Type::Function {
            params: params
                .iter()
                .map(|param| apply_subst(param, subst))
                .collect(),
            ret: Box::new(apply_subst(ret, subst)),
        },
        Type::Array { size, elem } => Type::Array {
            size: size.substitute(subst),
            elem: Box::new(apply_subst(elem, subst)),
        },
        other => other.clone(),
    }
}
