# Semantic compiler service

Implementation status: LNC-004 in progress. The contract and M0 gates are
complete; this package adds initial immutable, single-file snapshots and entity
indexes. It does not yet expose a live MCP server or source transactions.

The service, admission checks, identities, storage, and overlay handling are
Terlan code. The narrow bootstrap command `terlc emit-core` serializes results
from the existing authoritative compiler. It does not introduce another type
checker or a Rust MCP implementation.

## Run

Build the bootstrap exporter and its runtime once:

```sh
cargo build --locked -p terlan --bin terlc --bin terlan-vm
target/release/terlc check compiler/semantic/src
target/release/terlc run compiler/semantic/scripts/Snapshot.terls -- \
  "$PWD/target/debug/terlc" /path/to/sample.terl src/sample.terl /tmp/semantic-store
target/release/terlc run compiler/semantic/scripts/Entities.terls -- \
  /tmp/semantic-store s:THE_RETURNED_64_HEX_DIGEST
target/release/terlc run compiler/semantic/scripts/Entities.terls -- \
  /tmp/semantic-store s:THE_RETURNED_64_HEX_DIGEST declarations
```

The compiler executable is trusted host configuration, not an agent-selected
program. Its export runs with a 30-second timeout and an 8-MiB output bound.
No candidate application is executed. A failed check retains actual compiler
diagnostics and exports no checked Core. Stdout contains exactly one JSON
artifact, including for invalid programs; rendered diagnostics use stderr.

## Snapshot contract

`Snapshot.capture_file` freezes source before compilation. The manifest binds
source bytes, compiler binary, syntax contract, target, dependency interface
digests, flags, and static execution policy. `capture_overlay` additionally
binds a positive editor version and requires the expected disk digest before
and after compilation. It never writes editor contents into the working tree.
Disk captures use document version zero.

The initial compiler ancestry digest explicitly anchors the trusted bootstrap
binary: `sha256_domain_framed("terlan.semantic.bootstrap-root.v1", [binary_sha])`.
It is not a claim that compiler build ancestry has been independently verified.
Dependency interfaces are the actual interfaces supplied by the bootstrap
pipeline, including its required standard interfaces. Interface-only exports
include those dependencies too.

The snapshot ID hashes canonical manifest JSON without `snapshot_id` and the
normalized compiler artifact digest, using the domain
`terlan.semantic.snapshot.v1`. Physical staging paths are normalized only in
known origin fields; source literals are preserved. Store readers require the
publication marker and recheck source, document, export, and identity hashes.
Interrupted publication and artifact corruption cannot serve partial facts.
This store does not claim a durable multi-file source transaction; LNC-007 owns
that separate contract.

The current capture scopes one source file and loaded dependency interfaces.
Its analysis is explicitly `partial`, or `invalid` after compiler rejection.
Project source closures, imported implementation navigation, and generated
origin chains remain further work. Dependency interfaces alone do not establish
the correctness of every dependency implementation.

## Entity identity

`Entities.bindings` projects the compiler's resolved lexical binding evidence.
It preserves full unsigned compiler identities through their JSON spelling.
Handles bind logical source path, module, lexical path, compiler binding ID,
and name. Unrelated declaration insertion preserves IDs; rename invalidates
the old handle. Resolution requires both snapshot ID and expected entity
digest, with no fallback to matching names. Digests conservatively bind the
whole source, so source changes require refreshed selections even when IDs
remain stable.

`DeclarationEntities.declarations` indexes checked functions, receiver methods,
types, structs, and traits. IDs bind complete checked declaration payloads with
syntax `span` metadata removed. This conservative initial scheme preserves IDs
across unrelated declaration insertion and distinguishes same-name overloads;
any semantic payload change invalidates the declaration ID. Duplicate identities
are rejected. These handles are not public ABI fingerprints.

Compiler lexical spans currently cover enclosing syntax. The lexical catalog
reports `span_precision: enclosing_syntax`; these ranges must not be used as
exact rename edits. Unexported inferred local types, generated origins, other
entity categories, and pattern identities must remain unavailable until their
compiler evidence is implemented. LNC-004 stays open for those identity and
scope requirements.

## Checks

```sh
target/release/terlc test compiler/semantic/src/semantic/CompilerBridgeTest.terl
target/release/terlc test compiler/semantic/src/semantic/SnapshotTest.terl
target/release/terlc test compiler/semantic/src/semantic/EntitiesTest.terl
target/release/terlc test compiler/semantic/src/semantic/DeclarationEntitiesTest.terl
cargo test --locked -p terlan --lib commands::emit_core::tests -- --test-threads=1
```

The Terlan tests use `target/debug/terlc`, or the explicit
`TERLAN_SEMANTIC_TEST_COMPILER` override. Authored tests cover stale source and
forged-success rejection, immutable capture, corruption, invalid programs,
unsaved overlays, stable IDs, stale selection, rename invalidation, overloads,
and declaration payload changes. These are component checks, not a passed M1
gate or MCP interoperability claim.

Run these commands sequentially, or give concurrent invocations distinct
`--cache-dir` values. One parallel checkpoint run failed during project
interface preparation; its isolated replay passed. Shared-cache concurrency
is not established by this component checkpoint.
