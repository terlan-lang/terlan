//! Bootstrap artifact export for Terlan-owned semantic compiler services.
//!
//! This module serializes existing authoritative compiler results. Snapshot
//! identity, indexing, MCP handling, and edit/transaction policy belong in Terlan.

use std::io::{self, Write};
use std::process::ExitCode;

use serde_json::{Value, json};
use sha2::{Digest, Sha256};

use crate::{CliCommand, CliState};

/// Checks one source and writes one versioned CoreIR artifact to standard output.
pub(crate) fn run(cmd: CliCommand, state: CliState) -> ExitCode {
    let [path] = cmd.args.as_slice() else {
        eprintln!("terlc emit-core requires exactly one source file");
        return ExitCode::from(2);
    };
    let source = match crate::support::read_file(path) {
        Ok(source) => source,
        Err(message) => {
            eprintln!("{message}");
            return ExitCode::from(1);
        }
    };
    let (document, exit_code) = match export(path, &source, &state) {
        Ok(result) => result,
        Err(message) => {
            eprintln!("error[core_export]: {message}");
            return ExitCode::from(1);
        }
    };
    let stdout = io::stdout();
    let mut output = stdout.lock();
    if let Err(error) = serde_json::to_writer(&mut output, &document)
        .and_then(|()| writeln!(output).map_err(serde_json::Error::io))
    {
        eprintln!("error[core_export]: cannot write checked artifact: {error}");
        return ExitCode::from(1);
    }
    exit_code
}

fn digest(text: &str) -> String {
    Sha256::digest(text.as_bytes())
        .iter()
        .map(|byte| format!("{byte:02x}"))
        .collect()
}

fn dependencies(
    interfaces: &std::collections::HashMap<String, crate::terlan_hir::ModuleInterface>,
) -> Vec<Value> {
    let mut dependencies = interfaces
        .iter()
        .map(|(name, interface)| {
            let text = interface.to_terlan_interface_text();
            json!({"module": name, "interface_digest": digest(&text), "interface_source": text})
        })
        .collect::<Vec<_>>();
    dependencies.sort_by(|a, b| a["module"].as_str().cmp(&b["module"].as_str()));
    dependencies
}

fn export(path: &str, source: &str, state: &CliState) -> Result<(Value, ExitCode), String> {
    let target = super::check::effective_check_target_profile(source, state.target_profile)?;
    let result =
        crate::formal_pipeline::compile_syntax_module_through_phases_with_diagnostics_for_profile(
            path,
            source,
            // The pipeline's JSON diagnostic renderer writes to stdout. Keep
            // that channel exclusively for this command's single artifact;
            // the same structured diagnostics are embedded below.
            crate::DiagnosticFormat::Text {
                color: crate::ColorChoice::Never,
            },
            state.cache_dir.as_deref(),
            state.native_policy,
            target,
        );
    let mut diagnostics = Vec::new();
    for (phase, entries) in [
        ("parse", &result.parse_diagnostics),
        ("macro_expansion", &result.macro_expansion_diagnostics),
        ("include_expansion", &result.include_expansion_diagnostics),
        ("resolve", &result.resolve_diagnostics),
        ("typecheck", &result.typecheck_diagnostics),
        ("core", &result.core_diagnostics),
    ] {
        for entry in entries {
            diagnostics.push(json!({"phase": phase, "diagnostic": entry}));
        }
    }
    let successful = result.exit_code == ExitCode::SUCCESS;
    let (core, interface, dependencies, status) = if successful {
        if let Some(artifacts) = &result.artifacts {
            (
                serde_json::to_value(&artifacts.core).map_err(|error| error.to_string())?,
                json!(artifacts.core.interface_text()),
                dependencies(&artifacts.interfaces),
                "checked",
            )
        } else if let Some(artifacts) = &result.checked_interface {
            (
                Value::Null,
                json!(artifacts.interface.to_terlan_interface_text()),
                dependencies(&artifacts.interfaces),
                "interface_only",
            )
        } else {
            return Err("successful compiler result has no checked artifact".to_string());
        }
    } else {
        (Value::Null, Value::Null, Vec::new(), "invalid")
    };
    let declarations = if let Some(artifacts) = &result.artifacts {
        serde_json::to_value(&artifacts.syntax_output.declarations)
    } else if let Some(artifacts) = &result.checked_interface {
        serde_json::to_value(&artifacts.syntax_output.declarations)
    } else {
        Ok(json!([]))
    }
    .map_err(|error| error.to_string())?;
    let document = json!({
        "schema": "terlan.semantic.core-export.v1",
        "compiler_version": env!("CARGO_PKG_VERSION"),
        "syntax_contract": crate::validation::phase_manifest::current_syntax_contract_identity()?,
        "source_name": path,
        "source_digest": digest(source),
        "target_profile": target.as_str(),
        "native_policy": state.native_policy.as_str(),
        "status": status,
        "core": core,
        "interface_source": interface,
        "source_declarations": declarations,
        "dependencies": dependencies,
        "diagnostics": diagnostics,
    });
    Ok((document, result.exit_code))
}

#[cfg(test)]
mod tests {
    use super::*;

    fn checked(source: &str) -> Value {
        let (value, status) = export("sample.terl", source, &CliState::default()).unwrap();
        assert_eq!(status, ExitCode::SUCCESS);
        assert_eq!(value["status"], "checked");
        value
    }

    #[test]
    fn exports_checked_core_and_exact_source_identity() {
        let source =
            "module sample.\npub value(input: Int): Int -> let local = input + 1; local.\n";
        let value = checked(source);
        assert_eq!(value["source_digest"], digest(source));
        assert_eq!(value["core"]["schema"], "terlan.core_ir.v1");
        assert_eq!(value["core"]["module"], "sample");
        assert!(!value["source_declarations"].as_array().unwrap().is_empty());
        assert!(
            value["core"]["binding_identities"]["bindings"]
                .as_array()
                .unwrap()
                .iter()
                .any(|entry| entry["name"] == "local")
        );
    }

    #[test]
    fn invalid_source_never_exports_successful_core() {
        let (value, status) = export(
            "sample.terl",
            "module sample.\npub value(): Bool -> 1.\n",
            &CliState::default(),
        )
        .unwrap();
        assert_ne!(status, ExitCode::SUCCESS);
        assert_eq!(value["status"], "invalid");
        assert!(value["core"].is_null());
        assert!(!value["diagnostics"].as_array().unwrap().is_empty());
    }

    #[test]
    fn unrelated_declaration_preserves_exported_binding_identity() {
        let body = "pub value(input: Int): Int -> let local = input + 1; local.\n";
        let before = checked(&format!("module sample.\n{body}"));
        let after = checked(&format!("module sample.\npub other(): Int -> 0.\n{body}"));
        let id = |value: &Value| {
            value["core"]["binding_identities"]["bindings"]
                .as_array()
                .unwrap()
                .iter()
                .find(|entry| entry["name"] == "local")
                .unwrap()["id"]
                .clone()
        };
        assert_eq!(id(&before), id(&after));
    }
}
