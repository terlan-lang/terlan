//! Bootstrap artifact export for Terlan-owned semantic compiler services.
//!
//! This module serializes existing authoritative compiler results. Snapshot
//! identity, indexing, MCP handling, and edit/transaction policy belong in Terlan.

use std::io::{self, Write};
use std::path::Path;
use std::process::ExitCode;

use serde_json::{Value, json};
use sha2::{Digest, Sha256};

use crate::{CliCommand, CliState};

/// Checks a source or explicit source root and writes one versioned artifact.
pub(crate) fn run(cmd: CliCommand, state: CliState) -> ExitCode {
    let [path] = cmd.args.as_slice() else {
        eprintln!("terlc emit-core requires one source file or source root");
        return ExitCode::from(2);
    };
    let result = if Path::new(path).is_dir() {
        export_sources(Path::new(path), &state)
    } else {
        crate::support::read_file(path)
            .map_err(|error| error.to_string())
            .and_then(|source| export(path, &source, &state))
    };
    let (document, exit_code) = match result {
        Ok(result) => result,
        Err(message) => {
            eprintln!("error[core_export]: {message}");
            return ExitCode::from(1);
        }
    };
    let stdout = io::stdout();
    let mut output = stdout.lock();
    if let Err(error) = serde_json::to_writer(&mut output, &document)
        .and_then(|()| writeln!(output).map_err(serde_json::Error::io))
    {
        eprintln!("error[core_export]: cannot write checked artifact: {error}");
        return ExitCode::from(1);
    }
    exit_code
}

fn digest(text: &str) -> String {
    Sha256::digest(text.as_bytes())
        .iter()
        .map(|byte| format!("{byte:02x}"))
        .collect()
}

fn dependencies(
    interfaces: &std::collections::HashMap<String, crate::terlan_hir::ModuleInterface>,
) -> Vec<Value> {
    let mut dependencies = interfaces
        .iter()
        .map(|(name, interface)| {
            let text = interface.to_terlan_interface_text();
            json!({"module": name, "interface_digest": digest(&text), "interface_source": text})
        })
        .collect::<Vec<_>>();
    dependencies.sort_by(|a, b| a["module"].as_str().cmp(&b["module"].as_str()));
    dependencies
}

fn export(path: &str, source: &str, state: &CliState) -> Result<(Value, ExitCode), String> {
    export_with_interfaces(path, source, state, None)
}

fn export_with_interfaces(
    path: &str,
    source: &str,
    state: &CliState,
    source_graph: Option<&crate::formal_pipeline::interface_graph::SourceInterfaceGraph>,
) -> Result<(Value, ExitCode), String> {
    let target = super::check::effective_check_target_profile(source, state.target_profile)?;
    let (result, coverage_observations) =
        crate::terlan_typeck::coverage_observations::capture(|| {
            crate::formal_pipeline::compile_syntax_module_with_interfaces(
                path,
                source,
                // The pipeline's JSON diagnostic renderer writes to stdout. Keep
                // that channel exclusively for this command's single artifact;
                // the same structured diagnostics are embedded below.
                crate::DiagnosticFormat::Text {
                    color: crate::ColorChoice::Never,
                },
                crate::formal_pipeline::InterfaceInputs {
                    cache_dir: state.cache_dir.as_deref(),
                    source_graph,
                },
                state.native_policy,
                target,
                crate::validation::target_profile::TargetProfileCheckOptions::default(),
            )
        });
    let mut diagnostics = Vec::new();
    for (phase, entries) in [
        ("parse", &result.parse_diagnostics),
        ("macro_expansion", &result.macro_expansion_diagnostics),
        ("include_expansion", &result.include_expansion_diagnostics),
        ("resolve", &result.resolve_diagnostics),
        ("typecheck", &result.typecheck_diagnostics),
        ("core", &result.core_diagnostics),
    ] {
        for entry in entries {
            diagnostics.push(json!({"phase": phase, "diagnostic": entry}));
        }
    }
    let successful = result.exit_code == ExitCode::SUCCESS;
    let (core, interface, dependencies, status) = if successful {
        if let Some(artifacts) = &result.artifacts {
            (
                serde_json::to_value(&artifacts.core).map_err(|error| error.to_string())?,
                json!(artifacts.core.interface_text()),
                dependencies(&artifacts.interfaces),
                "checked",
            )
        } else if let Some(artifacts) = &result.checked_interface {
            (
                Value::Null,
                json!(artifacts.interface.to_terlan_interface_text()),
                dependencies(&artifacts.interfaces),
                "interface_only",
            )
        } else {
            return Err("successful compiler result has no checked artifact".to_string());
        }
    } else {
        (Value::Null, Value::Null, Vec::new(), "invalid")
    };
    let declarations = if let Some(artifacts) = &result.artifacts {
        serde_json::to_value(&artifacts.syntax_output.declarations)
    } else if let Some(artifacts) = &result.checked_interface {
        serde_json::to_value(&artifacts.syntax_output.declarations)
    } else {
        Ok(json!([]))
    }
    .map_err(|error| error.to_string())?;
    let module_name = result
        .artifacts
        .as_ref()
        .map(|artifacts| &artifacts.syntax_output.module_name)
        .or_else(|| {
            result
                .checked_interface
                .as_ref()
                .map(|artifacts| &artifacts.syntax_output.module_name)
        });
    let resolved_imports = successful.then_some(&result.resolved_imports);
    let purity_contracts = if successful {
        result
            .artifacts
            .as_ref()
            .map(|artifacts| {
                crate::formal_pipeline::resolution_metadata::purity_contracts(
                    &artifacts.core.interface,
                )
            })
            .or_else(|| {
                result.checked_interface.as_ref().map(|artifacts| {
                    crate::formal_pipeline::resolution_metadata::purity_contracts(
                        &artifacts.interface,
                    )
                })
            })
    } else {
        None
    };
    let document = json!({
        "schema": "terlan.semantic.core-export.v1",
        "compiler_version": env!("CARGO_PKG_VERSION"),
        "syntax_contract": crate::validation::phase_manifest::current_syntax_contract_identity()?,
        "source_name": path,
        "module_name": module_name,
        "source_digest": digest(source),
        "target_profile": target.as_str(),
        "native_policy": state.native_policy.as_str(),
        "status": status,
        "core": core,
        "interface_source": interface,
        "source_declarations": declarations,
        "resolved_imports": resolved_imports,
        "purity_contracts": purity_contracts,
        "coverage_observations": coverage_observations,
        "dependencies": dependencies,
        "diagnostics": diagnostics,
    });
    Ok((document, result.exit_code))
}

/// Exports the same shared source-interface graph used by project checking.
/// The Terlan caller owns freezing, scope selection, identities, and storage.
fn export_sources(root: &Path, state: &CliState) -> Result<(Value, ExitCode), String> {
    let files = crate::formal_pipeline::terlan_check_sources_in_dir(root)
        .map_err(|error| error.to_string())?;
    if files.is_empty() {
        return Err("source root contains no Terlan sources".to_string());
    }
    let mut inputs = Vec::new();
    let mut parsed = Vec::new();
    for path in files {
        let source = crate::support::read_file(&path.to_string_lossy())?;
        if let Ok(syntax) =
            crate::formal_pipeline::parse_source_as_syntax_output(&path.to_string_lossy(), &source)
        {
            crate::commands::source_layout::validate_module_layout(
                root,
                &path,
                &syntax.module_name,
            )?;
            parsed.push((path.clone(), syntax));
        }
        inputs.push((path, source));
    }
    let graph = crate::formal_pipeline::interface_graph::SourceInterfaceGraph::collect(
        parsed.iter().map(|(path, syntax)| (path.as_path(), syntax)),
        state.cache_dir.as_deref(),
    );
    let mut units = Vec::new();
    let mut successful = true;
    for (path, source) in inputs {
        let (document, status) =
            export_with_interfaces(&path.to_string_lossy(), &source, state, Some(&graph))?;
        successful &= status == ExitCode::SUCCESS;
        let relative = path
            .strip_prefix(root)
            .map_err(|error| error.to_string())?
            .to_str()
            .ok_or_else(|| "source path is not UTF-8".to_string())?
            .replace('\\', "/");
        units.push(json!({"path": relative, "export": document}));
    }
    Ok((
        json!({
            "schema": "terlan.semantic.core-bundle.v1",
            "compiler_version": env!("CARGO_PKG_VERSION"),
            "syntax_contract": crate::validation::phase_manifest::current_syntax_contract_identity()?,
            "status": if successful { "checked" } else { "invalid" },
            "units": units,
        }),
        if successful {
            ExitCode::SUCCESS
        } else {
            ExitCode::from(1)
        },
    ))
}

#[cfg(test)]
mod tests {
    use super::*;

    fn checked(source: &str) -> Value {
        let (value, status) = export("sample.terl", source, &CliState::default()).unwrap();
        assert_eq!(status, ExitCode::SUCCESS);
        assert_eq!(value["status"], "checked");
        value
    }

    #[test]
    fn exports_checked_core_and_exact_source_identity() {
        let source =
            "module sample.\npub value(input: Int): Int -> let local = input + 1; local.\n";
        let value = checked(source);
        assert_eq!(value["source_digest"], digest(source));
        assert_eq!(value["core"]["schema"], "terlan.core_ir.v1");
        assert_eq!(value["core"]["module"], "sample");
        assert!(!value["source_declarations"].as_array().unwrap().is_empty());
        assert!(
            value["core"]["binding_identities"]["bindings"]
                .as_array()
                .unwrap()
                .iter()
                .any(|entry| entry["name"] == "local")
        );
    }

    #[test]
    fn purity_contracts_are_checked_and_distinguish_overloads() {
        let value = checked(
            "module sample.\nimport std.io.Console.\n@pure\npub pick(value: Int): Int -> value.\npub pick(value: String): Int -> let printed = Console.println(value); 0.\n",
        );
        let contracts = value["purity_contracts"].as_array().unwrap();
        assert_eq!(contracts.len(), 2);
        let pure = contracts
            .iter()
            .find(|row| row["parameter_types"] == json!(["Int"]))
            .unwrap();
        let io = contracts
            .iter()
            .find(|row| row["parameter_types"] == json!(["String"]))
            .unwrap();
        assert_eq!(pure["compiler_proven_pure"], true);
        assert_eq!(io["compiler_proven_pure"], false);
    }

    #[test]
    fn coverage_observations_share_the_checked_finite_verdict() {
        let value = checked(
            "module sample.\npub value(flag: Bool): Bool -> case flag { true where false -> false; true -> true; false -> false }.\n",
        );
        let coverage = &value["coverage_observations"];
        assert_eq!(coverage["model"], "finite-pattern-coverage.v1");
        assert_eq!(coverage["truncated"], false);
        let cases = coverage["observations"]
            .as_array()
            .unwrap()
            .iter()
            .filter(|row| row["subject_kind"] == "case")
            .collect::<Vec<_>>();
        assert_eq!(cases.len(), 1);
        assert_eq!(cases[0]["owner"]["module"], "sample");
        assert_eq!(cases[0]["owner"]["name"], "value");
        assert_eq!(cases[0]["exhaustive"], true);
        assert_eq!(cases[0]["consistent"], true);
        assert_eq!(cases[0]["uncovered"], json!([]));
        assert_eq!(cases[0]["guarded_clauses"], json!([0]));
        assert_eq!(
            cases[0]["subject_syntax_digest"].as_str().unwrap().len(),
            64
        );
        // Capture is per export, never inherited from the previous source.
        let next = checked("module sample.\npub number(): Int -> 1.\n");
        assert!(
            !next["coverage_observations"]["observations"]
                .as_array()
                .unwrap()
                .iter()
                .any(|row| row["subject_kind"] == "case")
        );
    }

    #[test]
    fn incomplete_function_head_exports_its_actual_missing_variants() {
        let value = checked("module sample.\npub value({true, _}: {Bool, Bool}): Bool -> true.\n");
        let rows = value["coverage_observations"]["observations"]
            .as_array()
            .unwrap();
        let function = rows
            .iter()
            .find(|row| row["subject_kind"] == "function_clauses")
            .unwrap();
        assert_eq!(function["exhaustive"], false);
        assert_eq!(function["guarded_clauses"], json!([]));
        assert_eq!(function["uncovered"], json!(["(false, Bool)"]));
        assert!(value["diagnostics"].as_array().unwrap().iter().any(|row| {
            row["diagnostic"]["message"]
                .as_str()
                .unwrap()
                .contains("non-exhaustive function")
        }));
    }

    #[test]
    fn rejected_case_observations_are_not_successful_core() {
        let (value, status) = export(
            "sample.terl",
            "module sample.\npub value(flag: Bool): Bool -> case flag { true -> true }.\n",
            &CliState::default(),
        )
        .unwrap();
        assert_ne!(status, ExitCode::SUCCESS);
        assert_eq!(value["status"], "invalid");
        assert!(value["core"].is_null());
        assert!(value["purity_contracts"].is_null());
        let rows = value["coverage_observations"]["observations"]
            .as_array()
            .unwrap();
        let case = rows
            .iter()
            .find(|row| row["subject_kind"] == "case")
            .unwrap();
        assert_eq!(case["exhaustive"], false);
        assert_eq!(case["uncovered"], json!(["false"]));
    }

    #[test]
    fn invalid_source_never_exports_successful_core() {
        let (value, status) = export(
            "sample.terl",
            "module sample.\npub value(): Bool -> 1.\n",
            &CliState::default(),
        )
        .unwrap();
        assert_ne!(status, ExitCode::SUCCESS);
        assert_eq!(value["status"], "invalid");
        assert!(value["core"].is_null());
        assert!(!value["diagnostics"].as_array().unwrap().is_empty());
    }

    #[test]
    fn unrelated_declaration_preserves_exported_binding_identity() {
        let body = "pub value(input: Int): Int -> let local = input + 1; local.\n";
        let before = checked(&format!("module sample.\n{body}"));
        let after = checked(&format!("module sample.\npub other(): Int -> 0.\n{body}"));
        let id = |value: &Value| {
            value["core"]["binding_identities"]["bindings"]
                .as_array()
                .unwrap()
                .iter()
                .find(|entry| entry["name"] == "local")
                .unwrap()["id"]
                .clone()
        };
        assert_eq!(id(&before), id(&after));
    }

    #[test]
    fn same_arity_overloads_retain_distinct_declaration_origins() {
        let value = checked(
            "module sample.\npub value(input: Int): Int -> input.\npub value(input: Float): Float -> input.\n",
        );
        let functions = value["core"]["functions"].as_array().unwrap();
        let declarations = value["source_declarations"].as_array().unwrap();
        assert_eq!(functions.len(), 2);
        for declaration in declarations {
            let Some(payload) = declaration.get("payload") else {
                continue;
            };
            if payload["kind"] != "function" {
                continue;
            }
            let matches = functions
                .iter()
                .filter(|function| function["source"]["declaration_span"] == declaration["span"])
                .collect::<Vec<_>>();
            assert_eq!(
                matches.len(),
                1,
                "each source overload has one exact Core origin"
            );
            assert_eq!(matches[0]["source"]["module"], "sample");
            assert_eq!(matches[0]["source"]["function"], "value");
            assert_eq!(
                matches[0]["params"][0]["ty"],
                payload["params"][0]["annotation"]["text"]
            );
        }
    }

    #[test]
    fn source_set_checks_imports_with_the_shared_interface_graph() {
        let root = tempfile::tempdir().unwrap();
        std::fs::write(
            root.path().join("library.terli"),
            "module library.\npub value(input: Int): Int.\n",
        )
        .unwrap();
        std::fs::write(
            root.path().join("main.terl"),
            "module main.\nimport library.{value}.\npub run(): Int -> value(1).\n",
        )
        .unwrap();
        let (bundle, status) = export_sources(root.path(), &CliState::default()).unwrap();
        assert_eq!(status, ExitCode::SUCCESS);
        assert_eq!(bundle["units"].as_array().unwrap().len(), 2);
        assert_eq!(bundle["units"][0]["export"]["module_name"], "library");
        assert_eq!(bundle["units"][0]["export"]["status"], "interface_only");
        assert_eq!(bundle["units"][1]["export"]["status"], "checked");
        assert_eq!(bundle["units"][1]["export"]["core"]["module"], "main");
    }

    #[test]
    fn a_rejected_source_prevents_successful_bundle_status() {
        let root = tempfile::tempdir().unwrap();
        std::fs::write(
            root.path().join("broken.terl"),
            "module broken.\npub value(): Bool -> 1.\n",
        )
        .unwrap();
        std::fs::write(
            root.path().join("valid.terl"),
            "module valid.\npub value(): Int -> 1.\n",
        )
        .unwrap();
        let (bundle, status) = export_sources(root.path(), &CliState::default()).unwrap();
        assert_ne!(status, ExitCode::SUCCESS);
        assert_eq!(bundle["status"], "invalid");
        assert_eq!(bundle["units"][0]["export"]["status"], "invalid");
        assert!(bundle["units"][0]["export"]["core"].is_null());
        assert_eq!(bundle["units"][1]["export"]["status"], "checked");
    }
}
