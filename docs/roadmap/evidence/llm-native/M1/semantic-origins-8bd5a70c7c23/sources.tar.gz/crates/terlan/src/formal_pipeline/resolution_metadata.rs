//! Deterministic serialization of the authoritative resolver's import bindings.

use crate::terlan_hir::ResolvedModule;

#[derive(Debug, Clone, PartialEq, Eq, PartialOrd, Ord, serde::Serialize)]
pub(crate) struct ResolvedImportMetadata {
    pub(crate) kind: &'static str,
    pub(crate) local_name: String,
    pub(crate) source_module: String,
    pub(crate) source_name: String,
    pub(crate) span_start: usize,
    pub(crate) span_end: usize,
}

pub(super) fn imports(resolved: &ResolvedModule) -> Vec<ResolvedImportMetadata> {
    let mut rows = Vec::new();
    for (kind, imported) in [
        ("type", &resolved.imported_types),
        ("trait", &resolved.imported_traits),
        ("constant", &resolved.imported_constants),
    ] {
        rows.extend(imported.values().map(|item| ResolvedImportMetadata {
            kind,
            local_name: item.local_name.clone(),
            source_module: item.source_module.clone(),
            source_name: item.source_name.clone(),
            span_start: item.span.start,
            span_end: item.span.end,
        }));
    }
    rows.sort();
    rows.dedup();
    rows
}
