"""Independent MCP SDK stdio peer. No production server implementation lives here."""

import argparse
import asyncio
from datetime import timedelta
import hashlib
from importlib.metadata import version
import json
import os
from pathlib import Path
import subprocess

from jsonschema import Draft202012Validator
from mcp import ClientSession, StdioServerParameters, types
from mcp.client.stdio import stdio_client
from mcp.shared.exceptions import McpError


async def validate(args):
    assert version("mcp") == "1.26.0" and version("jsonschema") == "4.25.1"
    root = args.root.resolve()
    compiler = args.compiler.resolve()
    schemas = root / "compiler/semantic/schemas"
    read = lambda name: json.loads((schemas / (name + ".schema.json")).read_text())
    entity_validator = Draft202012Validator(read("entity"))
    result_validator = Draft202012Validator(read("query-result"))
    errors = Draft202012Validator(read("query-error"))
    cases, artifacts = args.evidence_cases, args.evidence_artifacts

    def passed(name, evidence):
        cases.append({"case_id": name, "status": "passed", "evidence": evidence})

    server_args = ["semantic", "mcp", str(args.store.resolve()), args.snapshot,
                   "--cache-dir", str(args.cache.resolve())]
    parameters = StdioServerParameters(command=str(compiler), args=server_args,
                                      cwd=str(root), env=dict(os.environ, TERLAN_RUN_STDIO="1"))
    with args.stderr.open("x") as errlog:
        async with stdio_client(parameters, errlog=errlog) as (incoming, outgoing):
            async with ClientSession(incoming, outgoing, read_timeout_seconds=timedelta(seconds=120)) as client:
                initialized = await client.initialize()
                assert initialized.protocolVersion == "2025-11-25"
                assert initialized.capabilities.tools is not None
                assert initialized.capabilities.resources is not None
                assert not initialized.capabilities.resources.subscribe
                passed("mcp.initialize", initialized.model_dump(mode="json"))
                await client.send_ping()
                passed("mcp.ping", {})

                listed = await client.list_tools()
                assert [tool.name for tool in listed.tools] == ["terlan_query"]
                tool = listed.tools[0]
                assert tool.outputSchema is not None
                assert tool.inputSchema == read("query")
                Draft202012Validator.check_schema(tool.inputSchema)
                Draft202012Validator.check_schema(tool.outputSchema)
                output_validator = Draft202012Validator(tool.outputSchema)
                artifacts["tool"] = tool.model_dump(mode="json")
                passed("mcp.tool-discovery-and-schemas", {"tool": tool.name})

                resources, token, tokens = [], None, set()
                while True:
                    page = await client.list_resources(cursor=token)
                    resources.extend(page.resources)
                    token = page.nextCursor
                    if token is None:
                        break
                    assert token not in tokens
                    tokens.add(token)
                assert resources and len({str(row.uri) for row in resources}) == len(resources)
                assert all(str(row.uri).startswith("terlan://snapshots/" + args.snapshot + "/") for row in resources)
                passed("mcp.resource-discovery", {"count": len(resources), "continuations": len(tokens)})

                entities, manifest = [], None
                for descriptor in resources:
                    result = await client.read_resource(descriptor.uri)
                    assert len(result.contents) == 1
                    contents = result.contents[0]
                    assert isinstance(contents, types.TextResourceContents)
                    assert len(contents.text.encode()) <= 65536
                    document = json.loads(contents.text)
                    assert document["snapshot_id"] == args.snapshot
                    if str(descriptor.uri).endswith("/manifest"):
                        Draft202012Validator(read("snapshot")).validate(document)
                        manifest = document
                    else:
                        assert document["schema"] == "terlan.semantic.entity-page.v1"
                        assert document["status"] == "partial" and document["limitations"]
                        for entity in document["entities"]:
                            entity_validator.validate(entity)
                        entities.extend(document["entities"])
                assert manifest is not None and entities
                assert len({row["entity_id"] for row in entities}) == len(entities)
                artifacts["entities"] = entities
                passed("mcp.bounded-schema-valid-resources", {"entities": len(entities)})
                templates = await client.list_resource_templates()
                assert templates.resourceTemplates == []
                passed("mcp.empty-template-discovery", {})

                decide = next(row for row in entities if row["kind"] == "function" and row["name"] == "decide")

                def query(entity=decide, fact="type", **overrides):
                    document = {"schema": "terlan.semantic.query.v1", "snapshot_id": args.snapshot,
                                "target": {"entity_id": entity["entity_id"], "kind": entity["kind"],
                                           "expected_digest": entity["digest"]},
                                "fact": fact, "limits": {"max_bytes": 16384, "max_work": 10000}, "cursor": None}
                    document.update(overrides)
                    return document

                async def call(arguments, failed=False):
                    response = await client.call_tool("terlan_query", arguments)
                    assert response.isError is failed
                    assert isinstance(response.structuredContent, dict)
                    document = response.structuredContent
                    output_validator.validate(document)
                    (errors if failed else result_validator).validate(document)
                    assert len(response.content) == 1 and isinstance(response.content[0], types.TextContent)
                    assert json.loads(response.content[0].text) == document
                    return document

                signature = await call(query())
                assert signature["facts"][0]["value"]["return_type"] == "Bool"
                artifacts["query"] = signature
                passed("mcp.compiler-type-query", signature)
                expected = await call(query(fact="expected_values"))
                value = expected["facts"][0]["value"]
                assert value["literal_candidates"] == [False, True]
                assert value["exhaustive_for_type"] and not value["exhaustive_for_program_location"]
                assert value["verification_required"] and expected["status"] == "partial"
                passed("mcp.expected-values-constraints", expected)

                choices = [row for row in entities if row["kind"] == "function" and row["name"] == "choose"]
                assert len(choices) == 2
                signatures = [await call(query(entity=row)) for row in choices]
                assert {row["facts"][0]["value"]["return_type"] for row in signatures} == {"Int", "String"}
                passed("mcp.same-arity-overload-identity", {"entities": [row["entity_id"] for row in choices]})
                unavailable = await call(query(fact="ownership"))
                assert unavailable["status"] == "unavailable" and not unavailable["facts"] and unavailable["limitations"]
                passed("mcp.explicit-unknown", unavailable)

                stale = query()
                stale["target"]["expected_digest"] = "0" * 64
                rejected = await call(stale, failed=True)
                assert rejected["code"] == "semantic.entity.stale"
                passed("mcp.stale-entity-rejection", rejected)
                scoped = await call(query(snapshot_id="s:" + "0" * 64), failed=True)
                assert scoped["code"] == "semantic.mcp.snapshot_scope"
                passed("mcp.snapshot-scope-rejection", scoped)
                invalid = await call(query(limits={"max_bytes": 0, "max_work": 1000}), failed=True)
                passed("mcp.invalid-budget-tool-error", invalid)

                try:
                    await client.call_tool("unknown.tool", {})
                    raise AssertionError("Unknown tool accepted")
                except McpError as error:
                    assert error.error.code == -32602
                passed("mcp.unknown-tool-protocol-error", {"code": -32602})
                try:
                    await client.list_resources(cursor="c:" + "0" * 64)
                    raise AssertionError("Forged resource continuation accepted")
                except McpError as error:
                    assert error.error.code == -32602
                passed("mcp.forged-resource-cursor", {"code": -32602})
                try:
                    await client.read_resource("file:///etc/passwd")
                    raise AssertionError("Unadmitted URI accepted")
                except McpError as error:
                    assert error.error.code == -32002
                passed("mcp.resource-uri-confinement", {"code": -32002})

    request_path = args.output.with_suffix(".query-request.json")
    with request_path.open("x") as target:
        json.dump(query(), target)
    cli = await asyncio.to_thread(
        subprocess.run,
        [str(compiler), "semantic", "query", str(args.store.resolve()), str(request_path.resolve()),
         "--cache-dir", str(args.cache.resolve())],
        cwd=root, stdin=subprocess.DEVNULL, capture_output=True, timeout=120,
    )
    assert cli.returncode == 0, cli.stderr.decode(errors="replace")
    assert json.loads(cli.stdout) == signature
    passed("mcp.cli-query-parity", {"request_digest": hashlib.sha256(request_path.read_bytes()).hexdigest()})

    return {"schema": "terlan.semantic.mcp-peer-evidence.v1", "status": "passed",
            "protocol_version": "2025-11-25", "snapshot_id": args.snapshot,
            "compiler_digest": hashlib.sha256(compiler.read_bytes()).hexdigest(),
            "peer_versions": {"mcp": version("mcp"), "jsonschema": version("jsonschema")},
            "command": [str(compiler), *server_args], "cases": cases, "artifacts": artifacts,
            "scope": "Live independent SDK initialization, discovery, resources, compiler queries and rejection paths; not the full LNC-005 gate."}


def main():
    parser = argparse.ArgumentParser()
    for name in ("root", "compiler", "store", "cache", "output", "stderr"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--snapshot", required=True)
    args = parser.parse_args()
    args.evidence_cases, args.evidence_artifacts = [], {}
    try:
        report = asyncio.run(validate(args))
    except Exception as error:
        report = {"schema": "terlan.semantic.mcp-peer-evidence.v1", "status": "failed",
                  "error": str(error), "error_type": type(error).__name__,
                  "cases": args.evidence_cases, "artifacts": args.evidence_artifacts}
        import traceback
        traceback.print_exc()
    with args.output.open("x") as target:
        json.dump(report, target, indent=2, sort_keys=True)
        target.write("\n")
    print(json.dumps({"status": report["status"], "cases": len(report.get("cases", []))}))
    return 0 if report["status"] == "passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
