use super::*;

mod constructor_functions;
pub(super) use constructor_functions::canonicalize_physical_atom;
#[path = "core_lowering/default_arguments.rs"]
mod default_arguments;
#[path = "core_lowering/implementation_dependencies.rs"]
mod implementation_dependencies;
mod imported_atoms;
mod imported_nominals;
#[path = "core_lowering/native_declarations.rs"]
mod native_declarations;
mod opaque_values;
#[path = "core_lowering/receiver_defaults.rs"]
mod receiver_defaults;

/// Lowers resolved formal compiler state to the current core boundary.
///
/// Inputs:
/// - `resolved` compiler module produced by resolution and typechecking.
///
/// Output:
/// - Deterministic backend-neutral `CoreModule` payload.
///
/// Transformation:
/// - Copies the resolver interface into the core artifact and retains the
///   canonical module name.
/// - This function intentionally does not include backend-specific calls,
///   Vm syntax, or JVM/JS encoding assumptions.
pub fn lower_resolved_module_to_core(resolved: &ResolvedModule) -> CoreModule {
    let imports = lower_core_imports(resolved);
    let exports = lower_core_exports(&resolved.interface);
    let types = lower_core_types(&resolved.interface);
    let functions = lower_core_functions(&resolved.interface);
    let constructors = lower_core_constructors(&resolved.interface);
    let metadata = core_module_metadata(&functions, &types, &constructors);

    let mut core = CoreModule {
        schema: CORE_IR_SCHEMA.to_string(),
        module: resolved.name.clone(),
        source: CoreSourceIdentity {
            source_kind: "resolved_module".to_string(),
            source_path: None,
            syntax_contract_fingerprint: None,
        },
        imports,
        selected_function_imports: Vec::new(),
        exports,
        types,
        functions,
        constructors,
        templates: Vec::new(),
        trait_conformances: Vec::new(),
        binding_identities: CoreBindingIdentityEvidence::default(),
        termination: CoreTerminationEvidence::default(),
        metadata,
        interface: resolved.interface.clone(),
    };
    core.termination = analyze_core_termination(&core);
    core
}

/// Lowers syntax-output plus resolved formal compiler state to CoreIR.
///
/// Inputs:
/// - `module`: compiler-facing syntax output produced from the canonical syntax
///   contract.
/// - `resolved`: resolver artifact after formal typechecking.
///
/// Output:
/// - Deterministic backend-neutral `CoreModule` payload with function clause
///   and expression summaries.
///
/// Transformation:
/// - Starts from the resolver/interface Core boundary, attaches syntax contract
///   identity, and overlays syntax-output function clauses as Core summaries
///   without encoding backend syntax or emitted Vm forms.
pub fn lower_syntax_module_output_to_core(
    module: &SyntaxModuleOutput,
    resolved: &ResolvedModule,
) -> CoreModule {
    let (macro_expanded_module, _) = super::expand_syntax_raw_macros(module.clone());
    let (mut prepared_module, _) = super::prepare_syntax_constants_with_interfaces(
        &macro_expanded_module,
        &resolved.interface_map,
    );
    let mut core = lower_resolved_module_to_core(resolved);
    constructor_functions::materialize(&mut prepared_module, &mut core.constructors);
    let mut import_maps =
        super::collect_syntax_import_maps(&prepared_module, &resolved.interface_map);
    core.selected_function_imports = import_maps
        .function_imports
        .iter()
        .flat_map(|(local_name, targets)| {
            targets.iter().map(|target| CoreSelectedFunctionImport {
                local_name: local_name.clone(),
                module: target.module.clone(),
                function: target.function.clone(),
            })
        })
        .collect();
    core.selected_function_imports.sort();
    core.selected_function_imports.dedup();
    for (name, arity) in resolved.interface.functions.keys() {
        if super::core_intrinsic_lowering::core_primitive_intrinsic(&resolved.name, name, *arity)
            .is_some()
        {
            import_maps.function_imports.insert(
                name.clone(),
                vec![ImportedFunctionTarget {
                    module: resolved.name.clone(),
                    function: name.clone(),
                    arity: Some(*arity),
                    span: Span { start: 0, end: 0 },
                }],
            );
        }
    }
    canonicalize_core_module_aliases(&mut prepared_module, &import_maps.module_aliases);
    // Qualified function values need the same checked provider identity as
    // selected imports; their module alias is not a lexical closure capture.
    for (alias, provider) in &import_maps.module_aliases {
        if let Some(interface) = resolved.interface_map.get(provider) {
            for ((name, arity), signature) in &interface.functions {
                if signature.public {
                    import_maps
                        .function_imports
                        .entry(format!("{alias}.{name}"))
                        .or_default()
                        .push(ImportedFunctionTarget {
                            module: provider.clone(),
                            function: name.clone(),
                            arity: Some(*arity),
                            span: Span { start: 0, end: 0 },
                        });
                }
            }
        }
    }
    canonicalize_core_selected_function_imports(
        &mut prepared_module,
        &import_maps.function_imports,
    );
    default_arguments::materialize_default_call_arguments(
        &mut prepared_module,
        resolved,
        &core.constructors,
    );
    let receiver_sources = receiver_defaults::materialize(&mut prepared_module);
    let (mut prepared_module, _) =
        super::prepare_syntax_constants_with_interfaces(&prepared_module, &resolved.interface_map);
    annotate_syntax_comprehension_lifts(&mut prepared_module, resolved);
    let binding_identities = analyze_syntax_bindings(&prepared_module).evidence;
    imported_atoms::canonicalize(&mut prepared_module, resolved);
    let module = &prepared_module;
    core.functions = core_syntax_functions(module);
    for (arity, source) in receiver_sources {
        if let Some(function) = core
            .functions
            .iter_mut()
            .find(|function| function.name == source.function && function.arity == arity)
        {
            function.source = Some(source);
        }
    }
    constructor_functions::retain_sources(&mut core);
    let macro_functions = module
        .declarations
        .iter()
        .filter_map(|declaration| match &declaration.payload {
            SyntaxDeclarationPayload::Function {
                name,
                params,
                is_macro: true,
                ..
            } => Some((name.clone(), params.len())),
            _ => None,
        })
        .collect::<std::collections::HashSet<_>>();
    core.functions
        .retain(|function| !macro_functions.contains(&(function.name.clone(), function.arity)));
    core.exports.retain(|export| match &export.kind {
        CoreExportKind::Function { arity } => {
            !macro_functions.contains(&(export.name.clone(), *arity))
        }
        CoreExportKind::Type | CoreExportKind::Constructor { .. } => true,
    });
    let expanded_interface = syntax_module_output_to_interface(module);
    core.interface.struct_fields = expanded_interface.struct_fields;
    core.source = CoreSourceIdentity {
        source_kind: format!("{:?}", module.source_kind),
        source_path: None,
        syntax_contract_fingerprint: Some(module.syntax_contract.fingerprint.clone()),
    };
    core.imports = core_syntax_imports(module);
    merge_core_imports(
        &mut core.imports,
        core_resolved_executable_modules(module, resolved),
    );
    merge_core_imports(&mut core.imports, core_resolved_imported_modules(resolved));
    core.trait_conformances = core_syntax_trait_conformances(resolved);
    let syntax_types = core_syntax_type_representations(module);
    for type_decl in &mut core.types {
        if let Some((params, core_body)) = syntax_types.get(&type_decl.name) {
            type_decl.params = params.clone();
            if let Some(core_body) = core_body {
                type_decl.core_body = Some(core_body.clone());
            }
        }
    }

    let receiver_methods = core_receiver_method_dispatch_signatures(module, resolved);
    let template_prop_order = core_syntax_template_prop_order(module);
    let mut function_clauses = core_syntax_function_clauses(
        module,
        &core.functions,
        &receiver_methods,
        &template_prop_order,
    );
    let (mut structural_impl_functions, structural_impl_dispatch) =
        core_syntax_structural_impl_dispatch(
            module,
            resolved,
            &receiver_methods,
            &template_prop_order,
        );
    structural_impl_functions.extend(core_syntax_concrete_impl_functions(
        module,
        resolved,
        &receiver_methods,
        &template_prop_order,
    ));
    for function in &mut structural_impl_functions {
        function_clauses.insert(
            core_callable_signature_from_function(function),
            std::mem::take(&mut function.clauses),
        );
    }
    let native_operations = core_syntax_native_operations(module);
    opaque_values::lower(module, &mut function_clauses);
    let constructor_identities = core_constructor_identities(module, resolved, &core.constructors);
    resolve_constructor_identities_in_function_clauses(
        &mut function_clauses,
        &constructor_identities,
    );
    refresh_core_evidence_in_function_clauses(&mut function_clauses);
    core.functions.extend(structural_impl_functions);
    for function in &mut core.functions {
        let signature = core_callable_signature_from_function(function);
        if let Some(clauses) = function_clauses.get(&signature) {
            function.clauses = clauses.clone();
        }
        function.native_operation = native_operations.get(&signature).cloned();
        native_declarations::materialize(function);
    }
    rewrite_structural_impl_calls(&mut core.functions, &structural_impl_dispatch);
    rewrite_concrete_trait_calls(&mut core.functions, resolved);
    imported_nominals::qualify(&mut core, resolved);
    implementation_dependencies::retain(&mut core, resolved);
    core.functions.sort_by(|left, right| {
        left.name
            .cmp(&right.name)
            .then_with(|| left.arity.cmp(&right.arity))
    });
    core.metadata = core_module_metadata(&core.functions, &core.types, &core.constructors);
    core.binding_identities = binding_identities;
    core.termination = analyze_core_termination(&core);
    core
}

/// Attaches typechecked `GuardResult` lift containers before CoreIR lowering.
fn annotate_syntax_comprehension_lifts(module: &mut SyntaxModuleOutput, resolved: &ResolvedModule) {
    let mut lifts = Vec::new();
    for interface in std::iter::once(&resolved.interface).chain(resolved.interface_map.values()) {
        for conformance in &interface.trait_conformances {
            if conformance.is_negative {
                continue;
            }
            let Some(instance) = parse_trait_instance_from_text(&conformance.trait_ref) else {
                continue;
            };
            if instance.name.rsplit('.').next() != Some("GuardResult") {
                continue;
            }
            let [result, container] = instance.type_args.as_slice() else {
                continue;
            };
            lifts.push((type_constructor_head(result), container.clone()));
        }
    }

    for declaration in &mut module.declarations {
        let clauses = match &mut declaration.payload {
            SyntaxDeclarationPayload::Function { clauses, .. }
            | SyntaxDeclarationPayload::Method { clauses, .. } => clauses,
            _ => continue,
        };
        for clause in clauses {
            annotate_comprehension_lifts_in_expr(&mut clause.body, resolved, &lifts);
            if let Some(guard) = &mut clause.guard {
                annotate_comprehension_lifts_in_expr(guard, resolved, &lifts);
            }
        }
    }
}

fn annotate_comprehension_lifts_in_expr(
    expr: &mut SyntaxExprOutput,
    resolved: &ResolvedModule,
    lifts: &[(String, String)],
) {
    if expr.kind == SyntaxExprKind::ListComprehension {
        let guard_start = expr.patterns.len() + 1;
        let mut selected: Option<String> = None;
        for guard in expr.children.iter().skip(guard_start) {
            let Some(result) = syntax_call_return_type(guard, resolved) else {
                continue;
            };
            let head = type_constructor_head(result);
            for (result_head, container) in lifts {
                if type_heads_match(&head, result_head) {
                    selected.get_or_insert_with(|| container.clone());
                }
            }
        }
        expr.comprehension_lift = selected;
    }

    for child in &mut expr.children {
        annotate_comprehension_lifts_in_expr(child, resolved, lifts);
    }
    for guard in expr.let_guards.iter_mut().flatten() {
        annotate_comprehension_lifts_in_expr(guard, resolved, lifts);
    }
    for field in &mut expr.fields {
        annotate_comprehension_lifts_in_expr(&mut field.value, resolved, lifts);
    }
    for clause in expr.clauses.iter_mut().chain(&mut expr.catch_clauses) {
        if let Some(guard) = &mut clause.guard {
            annotate_comprehension_lifts_in_expr(guard, resolved, lifts);
        }
        annotate_comprehension_lifts_in_expr(&mut clause.body, resolved, lifts);
    }
    if let Some(after) = &mut expr.try_after {
        annotate_comprehension_lifts_in_expr(&mut after.trigger, resolved, lifts);
        annotate_comprehension_lifts_in_expr(&mut after.body, resolved, lifts);
    }
}

fn syntax_call_return_type<'a>(
    expr: &SyntaxExprOutput,
    resolved: &'a ResolvedModule,
) -> Option<&'a str> {
    if expr.kind != SyntaxExprKind::Call {
        return None;
    }
    let name = expr.children.first()?.text.as_deref()?;
    if let Some(module) = expr.remote.as_deref() {
        return resolved
            .interface_map
            .get(module)
            .and_then(|interface| interface.functions.get(&(name.to_string(), expr.arity)))
            .map(|signature| signature.return_type.as_str());
    }
    if let Some(symbol) = resolved
        .function_symbols
        .get(&(name.to_string(), expr.arity))
    {
        return Some(symbol.return_type.as_str());
    }
    let mut matches = resolved.interface_map.values().filter_map(|interface| {
        interface
            .functions
            .get(&(name.to_string(), expr.arity))
            .map(|signature| signature.return_type.as_str())
    });
    let first = matches.next()?;
    matches.all(|candidate| candidate == first).then_some(first)
}

fn type_constructor_head(ty: &str) -> String {
    ty.split_once('[')
        .map(|(head, _)| head)
        .unwrap_or(ty)
        .trim()
        .to_string()
}

fn type_heads_match(left: &str, right: &str) -> bool {
    left == right || left.rsplit('.').next() == right.rsplit('.').next()
}

/// Canonicalizes source-visible module aliases before syntax-to-Core lowering.
///
/// Inputs:
/// - `module`: the prepared syntax clone used only for CoreIR construction.
/// - `aliases`: resolver/typechecker import aliases mapped to provider modules.
///
/// Output:
/// - Function and method expressions carry canonical provider module names.
///
/// Transformation:
/// - Rewrites only the structured `remote` field, recursively through every
///   expression-owned child. Source text and the caller's syntax tree remain
///   untouched. This lets intrinsic lookup use semantic module identity while
///   preserving ordinary imported source such as `Process.yield_now()`.
fn canonicalize_core_module_aliases(
    module: &mut SyntaxModuleOutput,
    aliases: &HashMap<String, String>,
) {
    if aliases.is_empty() {
        return;
    }

    for declaration in &mut module.declarations {
        let callables = match &mut declaration.payload {
            SyntaxDeclarationPayload::Function {
                params, clauses, ..
            }
            | SyntaxDeclarationPayload::Method {
                params, clauses, ..
            } => vec![(params, clauses)],
            SyntaxDeclarationPayload::TraitImpl { methods, .. } => methods
                .iter_mut()
                .map(|method| (&mut method.params, &mut method.clauses))
                .collect(),
            _ => continue,
        };
        for (params, clauses) in callables {
            for param in params {
                if let Some(default) = &mut param.default {
                    canonicalize_core_expr_module_aliases(default, aliases);
                }
            }
            for clause in clauses {
                if let Some(guard) = &mut clause.guard {
                    canonicalize_core_expr_module_aliases(guard, aliases);
                }
                canonicalize_core_expr_module_aliases(&mut clause.body, aliases);
            }
        }
    }
}

fn canonicalize_core_expr_module_aliases(
    expr: &mut SyntaxExprOutput,
    aliases: &HashMap<String, String>,
) {
    if let Some(remote) = &mut expr.remote {
        if let Some(canonical) = aliases.get(remote) {
            *remote = canonical.clone();
        }
    }
    for child in &mut expr.children {
        canonicalize_core_expr_module_aliases(child, aliases);
    }
    for guard in expr.let_guards.iter_mut().flatten() {
        canonicalize_core_expr_module_aliases(guard, aliases);
    }
    for field in &mut expr.fields {
        canonicalize_core_expr_module_aliases(&mut field.value, aliases);
    }
    for clause in expr.clauses.iter_mut().chain(&mut expr.catch_clauses) {
        if let Some(guard) = &mut clause.guard {
            canonicalize_core_expr_module_aliases(guard, aliases);
        }
        canonicalize_core_expr_module_aliases(&mut clause.body, aliases);
    }
    if let Some(after) = &mut expr.try_after {
        canonicalize_core_expr_module_aliases(&mut after.trigger, aliases);
        canonicalize_core_expr_module_aliases(&mut after.body, aliases);
    }
}

/// Preserves selected-import callable identity before syntax-to-Core lowering.
///
/// A selected import is source-visible as a local name, but it is not a local
/// function. Type checking already resolves that name to one provider target.
/// Reattaching the provider and original function spelling here lets ordinary
/// remote-call and intrinsic lowering produce stable CoreIR identity, including
/// for aliased imports such as `ceil as round_up`.
fn canonicalize_core_selected_function_imports(
    module: &mut SyntaxModuleOutput,
    imports: &HashMap<String, Vec<ImportedFunctionTarget>>,
) {
    if imports.is_empty() {
        return;
    }

    for declaration in &mut module.declarations {
        match &mut declaration.payload {
            SyntaxDeclarationPayload::Function {
                params, clauses, ..
            } => {
                canonicalize_core_selected_import_function(params, clauses, imports);
            }
            SyntaxDeclarationPayload::Method {
                receiver,
                params,
                clauses,
                ..
            } => {
                let mut bound = params
                    .iter()
                    .map(|parameter| parameter.name.clone())
                    .collect::<std::collections::HashSet<_>>();
                bound.insert(receiver.name.clone());
                if let Some(default) = &mut receiver.default {
                    canonicalize_core_expr_selected_function_imports(default, imports, &bound);
                }
                for param in params {
                    if let Some(default) = &mut param.default {
                        canonicalize_core_expr_selected_function_imports(default, imports, &bound);
                    }
                }
                canonicalize_core_selected_import_clauses(clauses, imports, &bound);
            }
            SyntaxDeclarationPayload::TraitImpl { methods, .. } => {
                for method in methods {
                    canonicalize_core_selected_import_function(
                        &mut method.params,
                        &mut method.clauses,
                        imports,
                    );
                }
            }
            _ => {}
        }
    }
}

fn canonicalize_core_selected_import_function(
    params: &mut [crate::terlan_syntax::SyntaxParamOutput],
    clauses: &mut [crate::terlan_syntax::SyntaxFunctionClauseOutput],
    imports: &HashMap<String, Vec<ImportedFunctionTarget>>,
) {
    let bound = params
        .iter()
        .map(|parameter| parameter.name.clone())
        .collect::<std::collections::HashSet<_>>();
    for param in params {
        if let Some(default) = &mut param.default {
            canonicalize_core_expr_selected_function_imports(default, imports, &bound);
        }
    }
    canonicalize_core_selected_import_clauses(clauses, imports, &bound);
}

fn canonicalize_core_selected_import_clauses(
    clauses: &mut [crate::terlan_syntax::SyntaxFunctionClauseOutput],
    imports: &HashMap<String, Vec<ImportedFunctionTarget>>,
    bound: &std::collections::HashSet<String>,
) {
    for clause in clauses {
        if let Some(guard) = &mut clause.guard {
            canonicalize_core_expr_selected_function_imports(guard, imports, bound);
        }
        canonicalize_core_expr_selected_function_imports(&mut clause.body, imports, bound);
    }
}

fn canonicalize_core_expr_selected_function_imports(
    expr: &mut SyntaxExprOutput,
    imports: &HashMap<String, Vec<ImportedFunctionTarget>>,
    bound: &std::collections::HashSet<String>,
) {
    if expr.kind == SyntaxExprKind::FieldAccess {
        if let (Some(base), Some(field)) = (expr.children.first(), expr.text.as_deref()) {
            if base.kind == SyntaxExprKind::Var {
                if let Some(alias) = base.text.as_deref().filter(|alias| !bound.contains(*alias)) {
                    if let Some([target]) =
                        imports.get(&format!("{alias}.{field}")).map(Vec::as_slice)
                    {
                        if let Some(arity) = target.arity {
                            expr.kind = SyntaxExprKind::RemoteFunRef;
                            expr.remote = Some(target.module.clone());
                            expr.text = Some(target.function.clone());
                            expr.arity = arity;
                            expr.children.clear();
                        }
                    }
                }
            }
        }
    }
    if expr.kind == SyntaxExprKind::Var {
        if let Some(local_name) = expr.text.as_deref() {
            if !bound.contains(local_name) {
                if let Some([target]) = imports.get(local_name).map(Vec::as_slice) {
                    if let Some(arity) = target.arity {
                        expr.kind = SyntaxExprKind::RemoteFunRef;
                        expr.remote = Some(target.module.clone());
                        expr.text = Some(target.function.clone());
                        expr.arity = arity;
                    }
                }
            }
        }
    }
    if expr.kind == SyntaxExprKind::Let {
        let mut success_bound = bound.clone();
        for index in 0..expr.patterns.len() {
            if let Some(value) = expr.children.get_mut(index) {
                canonicalize_core_expr_selected_function_imports(value, imports, &success_bound);
            }
            collect_core_pattern_bindings(&expr.patterns[index], &mut success_bound);
            if let Some(guard) = expr.let_guards.get_mut(index).and_then(Option::as_mut) {
                canonicalize_core_expr_selected_function_imports(guard, imports, &success_bound);
            }
        }
        if let Some(body) = expr.children.get_mut(expr.patterns.len()) {
            canonicalize_core_expr_selected_function_imports(body, imports, &success_bound);
        }
        canonicalize_core_scoped_clauses(&mut expr.clauses, imports, bound);
        return;
    }
    if expr.kind == SyntaxExprKind::ListComprehension {
        let mut comprehension_bound = bound.clone();
        for index in 0..expr.patterns.len() {
            if let Some(source) = expr.children.get_mut(index + 1) {
                canonicalize_core_expr_selected_function_imports(
                    source,
                    imports,
                    &comprehension_bound,
                );
            }
            collect_core_pattern_bindings(&expr.patterns[index], &mut comprehension_bound);
        }
        for guard in expr.children.iter_mut().skip(expr.patterns.len() + 1) {
            canonicalize_core_expr_selected_function_imports(guard, imports, &comprehension_bound);
        }
        if let Some(yielded) = expr.children.first_mut() {
            canonicalize_core_expr_selected_function_imports(
                yielded,
                imports,
                &comprehension_bound,
            );
        }
        return;
    }
    if expr.kind == SyntaxExprKind::Call && expr.remote.is_none() {
        if let Some(callee) = expr.children.first_mut() {
            if matches!(callee.kind, SyntaxExprKind::Var | SyntaxExprKind::Atom) {
                if let Some(local_name) = callee.text.as_deref() {
                    if !bound.contains(local_name) {
                        if let Some([target]) = imports.get(local_name).map(Vec::as_slice) {
                            expr.remote = Some(target.module.clone());
                            callee.text = Some(target.function.clone());
                        }
                    }
                }
            }
        }
    }
    for (index, child) in expr.children.iter_mut().enumerate() {
        if expr.kind == SyntaxExprKind::Call
            && index == 0
            && matches!(child.kind, SyntaxExprKind::Var | SyntaxExprKind::Atom)
        {
            continue;
        }
        canonicalize_core_expr_selected_function_imports(child, imports, bound);
    }
    for guard in expr.let_guards.iter_mut().flatten() {
        canonicalize_core_expr_selected_function_imports(guard, imports, bound);
    }
    for field in &mut expr.fields {
        canonicalize_core_expr_selected_function_imports(&mut field.value, imports, bound);
    }
    canonicalize_core_scoped_clauses(&mut expr.clauses, imports, bound);
    canonicalize_core_scoped_clauses(&mut expr.catch_clauses, imports, bound);
    if let Some(after) = &mut expr.try_after {
        canonicalize_core_expr_selected_function_imports(&mut after.trigger, imports, bound);
        canonicalize_core_expr_selected_function_imports(&mut after.body, imports, bound);
    }
}

fn canonicalize_core_scoped_clauses(
    clauses: &mut [crate::terlan_syntax::SyntaxClauseOutput],
    imports: &HashMap<String, Vec<ImportedFunctionTarget>>,
    bound: &std::collections::HashSet<String>,
) {
    for clause in clauses {
        let mut clause_bound = bound.clone();
        for pattern in &clause.patterns {
            collect_core_pattern_bindings(pattern, &mut clause_bound);
        }
        if let Some(guard) = &mut clause.guard {
            canonicalize_core_expr_selected_function_imports(guard, imports, &clause_bound);
        }
        canonicalize_core_expr_selected_function_imports(&mut clause.body, imports, &clause_bound);
    }
}

fn collect_core_pattern_bindings(
    pattern: &crate::terlan_syntax::SyntaxPatternOutput,
    bound: &mut std::collections::HashSet<String>,
) {
    if matches!(
        pattern.kind,
        crate::terlan_syntax::SyntaxPatternKind::Var
            | crate::terlan_syntax::SyntaxPatternKind::Alias
            | crate::terlan_syntax::SyntaxPatternKind::StringCapture
    ) {
        if let Some(name) = &pattern.text {
            bound.insert(name.clone());
        }
    }
    for child in &pattern.children {
        collect_core_pattern_bindings(child, bound);
    }
    for field in &pattern.fields {
        collect_core_pattern_bindings(&field.value, bound);
    }
}

/// Collects inferred or explicit native operation identities by callable ABI.
fn core_syntax_native_operations(
    module: &SyntaxModuleOutput,
) -> HashMap<CoreCallableSignature, String> {
    module
        .declarations
        .iter()
        .filter_map(|declaration| {
            let operation = crate::compiler::native_bindings::declaration_operation(
                &module.module_name,
                declaration,
            )?;
            match &declaration.payload {
                SyntaxDeclarationPayload::Function { name, params, .. } => Some((
                    core_callable_signature_from_syntax_params(name, params),
                    operation,
                )),
                SyntaxDeclarationPayload::Method {
                    receiver,
                    name,
                    params,
                    ..
                } => {
                    let mut receiver_first_params = Vec::with_capacity(params.len() + 1);
                    receiver_first_params.push(receiver.as_ref().clone());
                    receiver_first_params.extend(params.iter().cloned());
                    Some((
                        core_callable_signature_from_syntax_params(name, &receiver_first_params),
                        operation,
                    ))
                }
                _ => None,
            }
        })
        .collect()
}

/// Lowers exact syntax-backed callable declarations into typed CoreIR.
///
/// The resolver interface also contains compatibility projections and
/// qualified import signatures. Executable CoreIR must instead retain one
/// function per source declaration so bodies, native annotations, and typed
/// overload identities stay aligned before application-wide qualification.
fn core_syntax_functions(module: &SyntaxModuleOutput) -> Vec<CoreFunction> {
    let mut functions = module
        .declarations
        .iter()
        .filter_map(|declaration| match &declaration.payload {
            SyntaxDeclarationPayload::Function {
                name,
                generic_params,
                generic_bounds,
                params,
                return_type,
                is_public,
                is_macro: false,
                ..
            } => Some(CoreFunction {
                receiver_method: false,
                receiver_mutable: false,
                receiver_command: false,
                trait_method: None,
                source: Some(CoreFunctionSource {
                    module: module.module_name.clone(),
                    function: name.clone(),
                    arity: params.len(),
                    declaration_span: Some(declaration.span.into()),
                }),
                name: name.clone(),
                arity: params.len(),
                public: *is_public,
                generic_params: generic_params.clone(),
                generic_bounds: generic_bounds
                    .iter()
                    .filter_map(|bound| core_type_from_text(bound))
                    .collect(),
                native_operation: None,
                params: params.iter().map(core_syntax_param).collect(),
                return_type: return_type.text.clone(),
                core_return_type: core_type_from_text(&return_type.text),
                clauses: Vec::new(),
            }),
            SyntaxDeclarationPayload::Method {
                receiver,
                name,
                generic_params,
                generic_bounds,
                params,
                return_type,
                is_public,
                ..
            } => {
                let internal_return = super::declarations::mutable_receiver_internal_return_type(
                    receiver,
                    return_type,
                );
                let mut core_params = Vec::with_capacity(params.len() + 1);
                core_params.push(core_syntax_param(receiver));
                core_params.extend(params.iter().map(core_syntax_param));
                Some(CoreFunction {
                    receiver_method: true,
                    receiver_mutable: receiver.is_mutable,
                    receiver_command: receiver.is_mutable
                        && super::declarations::is_unit_type_text(&return_type.text),
                    trait_method: None,
                    source: Some(CoreFunctionSource {
                        module: module.module_name.clone(),
                        function: name.clone(),
                        arity: core_params.len(),
                        declaration_span: Some(declaration.span.into()),
                    }),
                    name: name.clone(),
                    arity: core_params.len(),
                    public: *is_public,
                    generic_params: generic_params.clone(),
                    generic_bounds: generic_bounds
                        .iter()
                        .filter_map(|bound| core_type_from_text(bound))
                        .collect(),
                    native_operation: None,
                    params: core_params,
                    return_type: internal_return.to_string(),
                    core_return_type: core_type_from_text(internal_return),
                    clauses: Vec::new(),
                })
            }
            _ => None,
        })
        .collect::<Vec<_>>();
    functions.sort_by(|left, right| {
        left.name
            .cmp(&right.name)
            .then_with(|| left.arity.cmp(&right.arity))
            .then_with(|| {
                left.params
                    .iter()
                    .map(|param| param.ty.as_str())
                    .cmp(right.params.iter().map(|param| param.ty.as_str()))
            })
    });
    functions
}

/// Converts one syntax parameter into its typed CoreIR representation.
fn core_syntax_param(
    parameter: &crate::terlan_syntax::syntax_output::SyntaxParamOutput,
) -> CoreParam {
    CoreParam {
        name: parameter.name.clone(),
        ty: parameter.annotation.text.clone(),
        core_ty: core_type_from_text(&parameter.annotation.text),
    }
}

/// Collects declaration-order template props for CoreIR template-call lowering.
///
/// Inputs:
/// - `module`: syntax-output module containing template declarations.
///
/// Output:
/// - Template name to declaration-order prop-name list.
///
/// Transformation:
/// - Preserves only the metadata needed to map `Page(...)` positional calls
///   into backend-neutral template-instantiation fields.
fn core_syntax_template_prop_order(module: &SyntaxModuleOutput) -> HashMap<String, Vec<String>> {
    module
        .declarations
        .iter()
        .filter_map(|declaration| match &declaration.payload {
            SyntaxDeclarationPayload::Template { name, props, .. } => Some((
                name.clone(),
                props
                    .iter()
                    .map(|prop| prop.name.clone())
                    .collect::<Vec<_>>(),
            )),
            _ => None,
        })
        .collect()
}

use super::core_interface::*;
use super::core_proof::*;
