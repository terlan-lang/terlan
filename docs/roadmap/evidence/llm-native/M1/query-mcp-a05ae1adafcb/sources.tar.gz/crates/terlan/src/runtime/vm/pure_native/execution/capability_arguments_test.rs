//! Local VM calls do not inherit the external worker's narrower wire vocabulary.

use super::*;
use crate::runtime::native_image::managed::{
    ManagedClosureDescriptor, ManagedClosureImageGeneration,
};
use crate::runtime::vm::bitstring::VmBitString;
use crate::runtime::vm::NativeClosureValue;
use std::sync::Arc;

fn package(arguments: Vec<ReplValue>) -> PureNativeCapabilityRequest {
    PureNativeCapabilityRequest {
        capability: "package-native".into(),
        operation: "test.external.operation".into(),
        arguments: vec![],
        package_arguments: Some(arguments),
        result_type: TvmBoundaryType::Unit,
    }
}

#[test]
fn built_in_arguments_are_borrowed_without_cloning() {
    let request = PureNativeCapabilityRequest {
        capability: "stdio".into(),
        operation: "std.io.console.println".into(),
        arguments: vec![NativeBoundaryTerm::Text("line".into())],
        package_arguments: None,
        result_type: TvmBoundaryType::Unit,
    };
    assert!(matches!(
        request.boundary_arguments().unwrap(),
        std::borrow::Cow::Borrowed(_)
    ));
    assert_eq!(
        request.boundary_arguments().unwrap().as_ref(),
        request.arguments
    );
}

#[test]
fn binary_file_write_has_a_fixed_typed_capability_frame() {
    assert_eq!(
        crate::runtime::native_image::control::tvm_fixed_capability_frame_words(61),
        Some(6)
    );
    assert_eq!(
        capability_identity(61).unwrap(),
        (
            "filesystem".to_string(),
            "std.io.file.write_bytes".to_string()
        )
    );
}

#[test]
fn console_input_is_a_vm_owned_fixed_capability_not_an_external_worker_operation() {
    assert_eq!(crate::runtime::native_image::control::tvm_fixed_capability_frame_words(62), Some(5));
    assert_eq!(capability_identity(62).unwrap(), ("stdio".to_string(), "std.io.console.read_line".to_string()));
    assert_eq!(crate::terlan_native_boundary::dispatch::operation_arity("std.io.console.read_line"), None);
}

#[test]
fn wire_conversion_uses_typed_package_values_not_stale_wire_fields() {
    let mut request = package(vec![ReplValue::Tuple(vec![
        ReplValue::Int(7),
        ReplValue::String("value".into()),
        ReplValue::Map(vec![(
            ReplValue::Int(1),
            ReplValue::String("mapped".into()),
        )]),
    ])]);
    request.arguments = vec![NativeBoundaryTerm::Int(0)];
    assert_eq!(
        request.boundary_arguments().unwrap().as_ref(),
        &[NativeBoundaryTerm::Tuple(vec![
            NativeBoundaryTerm::Int(7),
            NativeBoundaryTerm::Text("value".into()),
            NativeBoundaryTerm::Map(vec![(
                NativeBoundaryTerm::Int(1),
                NativeBoundaryTerm::Text("mapped".into())
            )]),
        ])]
    );
    assert!(request.package_arguments.is_some());
}

#[test]
fn unsupported_external_values_remain_vm_owned_and_do_not_leak_in_errors() {
    let closure = ReplValue::Closure(Arc::new(NativeClosureValue {
        descriptor: Arc::new(
            ManagedClosureDescriptor::new(
                ManagedClosureImageGeneration::new([7; 32]).unwrap(),
                1,
                vec![],
                vec![TvmBoundaryType::Unit],
                vec![TvmBoundaryType::String],
            )
            .unwrap(),
        ),
        captures: vec![ReplValue::String("private-payload".into())].into_boxed_slice(),
    }));
    for value in [
        closure,
        ReplValue::Set(vec![ReplValue::String("private-payload".into())]),
        ReplValue::BitString(VmBitString::from_bytes(&[0xa0], 3).unwrap()),
    ] {
        let request = package(vec![ReplValue::Tuple(vec![ReplValue::Map(vec![(
            ReplValue::String("private-payload".into()),
            value,
        )])])]);
        let original = request.package_arguments.clone();
        let error = request.boundary_arguments().unwrap_err();
        assert!(error.starts_with("error[pure_native_capability_argument]"));
        assert!(!error.contains("private-payload"));
        assert_eq!(request.package_arguments, original);
    }
}
